import { createClient, type SupabaseClient } from '@supabase/supabase-js';

let _supabase: SupabaseClient | null = null;

/**
 * Server-side Supabase client using SERVICE_ROLE key.
 * 
 * Service role key bypasses RLS — this is intentional because
 * ALL database access goes through our API routes which handle
 * their own auth/authorization via JWT.
 * 
 * NEVER expose this client or the service role key to the browser.
 */
export function getSupabase(): SupabaseClient {
  if (!_supabase) {
    const url = process.env.SUPABASE_URL;
    // Prefer service role key (bypasses RLS), fallback to anon key
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
    
    if (!url || !key || !url.startsWith('http')) {
      throw new Error(
        'Supabase belum dikonfigurasi. Set SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY di .env.local'
      );
    }
    
    _supabase = createClient(url, key, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
  }
  return _supabase;
}

// Backwards compatible export — lazy-initialized proxy
export const supabase = new Proxy({} as SupabaseClient, {
  get(_, prop) {
    const client = getSupabase() as unknown as Record<string | symbol, unknown>;
    return client[prop];
  },
});
