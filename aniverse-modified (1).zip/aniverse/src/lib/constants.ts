// AniVerse Constants

export const RANKS = [
  { minLv: 0,   name: 'Newbie',        color: '#94A3B8', bg: '#1E293B', emoji: '🌱' },
  { minLv: 10,  name: 'Beginner',      color: '#0EA5E9', bg: '#0C4A6E', emoji: '👁️' },
  { minLv: 25,  name: 'Watcher',       color: '#8B5CF6', bg: '#3B0764', emoji: '🎌' },
  { minLv: 50,  name: 'Otaku',         color: '#F59E0B', bg: '#78350F', emoji: '⭐' },
  { minLv: 75,  name: 'Senpai',        color: '#10B981', bg: '#064E3B', emoji: '💎' },
  { minLv: 100, name: 'Anime Master',  color: '#EF4444', bg: '#7F1D1D', emoji: '👑' },
];

export const XP_PER_WATCH = 10;
export const XP_PER_LEVEL = 100;
export const MIN_WATCH_PROGRESS = 80; // percent
export const MIN_WATCH_TIME = 300; // 5 minutes in seconds

export function getLevel(xp: number): number {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

export function getTitle(level: number): string {
  if (level >= 100) return 'Anime Master';
  if (level >= 75) return 'Senpai';
  if (level >= 50) return 'Otaku';
  if (level >= 25) return 'Watcher';
  if (level >= 10) return 'Beginner';
  return 'Newbie';
}

export function getRank(level: number) {
  let rank = RANKS[0];
  for (const r of RANKS) {
    if (level >= r.minLv) rank = r;
  }
  return rank;
}

export function getXpProgress(xp: number): number {
  return (xp % XP_PER_LEVEL) / XP_PER_LEVEL * 100;
}

export function getXpToNextLevel(xp: number): number {
  return XP_PER_LEVEL - (xp % XP_PER_LEVEL);
}

export const GRADIENT_PALETTES = [
  ['#0f0c29', '#302b63'],
  ['#0d324d', '#7f5a83'],
  ['#134e5e', '#71b280'],
  ['#c94b4b', '#4b134f'],
  ['#f953c6', '#b91d73'],
  ['#1a1a2e', '#16213e'],
  ['#4facfe', '#00d4e0'],
  ['#2c3e50', '#fd746c'],
  ['#43b89c', '#7ec8e3'],
  ['#560bad', '#3a0ca3'],
  ['#f7971e', '#ffd200'],
  ['#00c6ff', '#0072ff'],
];

export function getGradient(index: number): string {
  const g = GRADIENT_PALETTES[index % GRADIENT_PALETTES.length];
  return `linear-gradient(135deg, ${g[0]}, ${g[1]})`;
}
