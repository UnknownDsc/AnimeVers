const API_BASE = process.env.ANIME_API_BASE || 'https://www.sankavollerei.com/anime';

// Cache store for server-side caching
const cache = new Map<string, { data: unknown; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

async function fetchWithCache<T>(path: string, ttl = CACHE_TTL): Promise<T> {
  const cacheKey = path;
  const cached = cache.get(cacheKey);
  
  if (cached && Date.now() - cached.timestamp < ttl) {
    return cached.data as T;
  }
  
  const url = `${API_BASE}${path}`;
  console.log(`[API Fetch] ${url}`);
  
  const response = await fetch(url, {
    next: { revalidate: 300 },
    headers: {
      'Accept': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  const text = await response.text();
  try {
    const data = JSON.parse(text);
    cache.set(cacheKey, { data, timestamp: Date.now() });
    return data as T;
  } catch (e) {
    throw new Error('Invalid JSON response');
  }
}

export async function getHome() {
  return fetchWithCache('/home');
}

export async function getOngoingAnime(page = 1) {
  return fetchWithCache(`/ongoing-anime?page=${page}`);
}

export async function getCompleteAnime(page = 1) {
  return fetchWithCache(`/complete-anime?page=${page}`);
}

export async function getAnimeDetail(animeId: string) {
  return fetchWithCache(`/anime/${animeId}`, 10 * 60 * 1000);
}

export async function getEpisodeDetail(episodeId: string) {
  return fetchWithCache(`/episode/${episodeId}`, 10 * 60 * 1000);
}

export async function getServerUrl(serverId: string) {
  return fetchWithCache(`/server/${serverId}`, 30 * 60 * 1000);
}

export async function getGenres() {
  return fetchWithCache('/genre', 60 * 60 * 1000);
}

export async function getGenreAnime(genreId: string, page = 1) {
  return fetchWithCache(`/genre/${genreId}?page=${page}`);
}

export async function getSchedule() {
  return fetchWithCache('/schedule', 30 * 60 * 1000);
}

export async function searchAnime(query: string) {
  try {
    // Coba format 1: ?q=query
    return await fetchWithCache(`/search?q=${encodeURIComponent(query)}`, 60 * 1000);
  } catch (err) {
    console.warn('[Search Fallback] Trying format 2...');
    try {
      // Coba format 2: /search/query (Beberapa API menggunakan ini)
      return await fetchWithCache(`/search/${encodeURIComponent(query)}`, 60 * 1000);
    } catch (err2) {
      console.error('[Search Critical Failure]', err2);
      // Jika semua gagal, kembalikan array kosong agar aplikasi tidak crash 500
      return { status: "success", data: [] };
    }
  }
}
