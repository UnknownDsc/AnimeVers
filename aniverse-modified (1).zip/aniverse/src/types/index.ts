// Type definitions for AniVerse

export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  xp: number;
  level: number;
  title: string;
  is_banned: boolean;
  ban_reason?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface UserPublic {
  id: string;
  username: string;
  role: UserRole;
  xp: number;
  level: number;
  title: string;
  is_banned: boolean;
  created_at: string;
}

export interface AnimeListItem {
  title: string;
  poster: string;
  episodes: number;
  releaseDay?: string;
  latestReleaseDate?: string;
  lastReleaseDate?: string;
  score?: string;
  animeId: string;
  href: string;
  otakudesuUrl?: string;
}

export interface AnimeDetail {
  title: string;
  poster: string;
  japanese?: string;
  score?: string;
  producers?: string;
  type?: string;
  status?: string;
  episodes?: number | null;
  duration?: string;
  aired?: string;
  studios?: string;
  batch?: string | null;
  synopsis?: {
    paragraphs: string[];
    connections: unknown[];
  };
  genreList?: Genre[];
  episodeList?: EpisodeListItem[];
  recommendedAnimeList?: AnimeListItem[];
}

export interface Genre {
  title: string;
  genreId: string;
  href: string;
  otakudesuUrl?: string;
}

export interface EpisodeListItem {
  title: string;
  eps: number;
  date: string;
  episodeId: string;
  href: string;
  otakudesuUrl?: string;
}

export interface ServerQuality {
  title: string;
  serverList: ServerItem[];
}

export interface ServerItem {
  title: string;
  serverId: string;
  href: string;
}

export interface EpisodeDetail {
  title: string;
  animeId: string;
  releaseTime?: string;
  defaultStreamingUrl: string;
  hasPrevEpisode: boolean;
  prevEpisode: EpisodeNav | null;
  hasNextEpisode: boolean;
  nextEpisode: EpisodeNav | null;
  server: {
    qualities: ServerQuality[];
  };
  downloadUrl?: {
    qualities: DownloadQuality[];
  };
  info?: {
    credit?: string;
    encoder?: string;
    duration?: string;
    type?: string;
    genreList?: Genre[];
    episodeList?: EpisodeListItem[];
  };
}

export interface EpisodeNav {
  title: string;
  episodeId: string;
  href: string;
  otakudesuUrl?: string;
}

export interface DownloadQuality {
  title: string;
  size: string;
  urls: { title: string; url: string }[];
}

export interface Comment {
  id: string;
  user_id: string;
  episode_id: string;
  content: string;
  created_at: string;
  username?: string;
}

export interface Favorite {
  id: string;
  user_id: string;
  anime_id: string;
  anime_title?: string;
  anime_poster?: string;
  created_at: string;
}

export interface HistoryItem {
  id: string;
  user_id: string;
  anime_id: string;
  anime_title?: string;
  anime_poster?: string;
  episode_id: string;
  episode_number?: number;
  progress: number;
  updated_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  anime_id: string;
  anime_title?: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  anime_id?: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface ApiResponse<T = unknown> {
  status: string;
  statusCode: number;
  data: T;
  pagination?: {
    currentPage: number;
    hasPrevPage: boolean;
    prevPage: number | null;
    hasNextPage: boolean;
    nextPage: number | null;
    totalPages: number;
  } | null;
}

export interface HomeData {
  ongoing: {
    href: string;
    animeList: AnimeListItem[];
  };
  completed: {
    href: string;
    animeList: AnimeListItem[];
  };
}

export interface JWTPayload {
  id: string;
  username: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

export interface AdminLog {
  id: string;
  admin_id: string;
  action: string;
  target_type?: string;
  target_id?: string;
  details?: Record<string, unknown>;
  created_at: string;
  admin_username?: string;
}

export interface SiteSetting {
  key: string;
  value: Record<string, unknown>;
  updated_at: string;
}

export interface AdminStats {
  totalUsers: number;
  totalAdmins: number;
  totalBanned: number;
  totalComments: number;
  totalFavorites: number;
  totalXpLogs: number;
  recentUsers: UserPublic[];
  recentComments: (Comment & { username?: string })[];
}
