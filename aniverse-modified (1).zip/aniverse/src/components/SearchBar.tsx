'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import type { AnimeListItem } from '@/types';

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<AnimeListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  const search = useCallback(async (q: string) => {
    if (q.length < 2) { setResults([]); setOpen(false); return; }
    setLoading(true);
    setOpen(true);
    try {
      const res = await fetch(`/api/anime/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      const list = data?.data?.animeList || [];
      setResults(list);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleInput = (val: string) => {
    setQuery(val);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (!val.trim()) { setOpen(false); return; }
    setLoading(true);
    setOpen(true);
    timerRef.current = setTimeout(() => search(val.trim()), 400);
  };

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  return (
    <div className="px-4 pt-4 relative z-20" ref={wrapRef}>
      <div className="flex items-center gap-2.5 bg-bg-secondary border border-border-light rounded-2xl px-3.5 py-3 transition-all focus-within:border-sky-d focus-within:shadow-[0_4px_20px_rgba(14,165,233,0.18)]">
        <svg viewBox="0 0 24 24" className="w-[18px] h-[18px] shrink-0 stroke-text-muted fill-none" strokeWidth="2" strokeLinecap="round">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input
          type="search"
          value={query}
          onChange={e => handleInput(e.target.value)}
          placeholder="Cari anime di sini..."
          className="flex-1 bg-transparent border-none outline-none text-sm text-text-primary placeholder:text-text-muted"
          autoComplete="off"
        />
      </div>

      {open && (
        <div className="absolute top-full left-4 right-4 -mt-1 bg-bg-secondary border border-sky-d border-t-0 rounded-b-2xl max-h-[260px] overflow-y-auto shadow-[0_12px_32px_rgba(14,165,233,0.14)] z-40">
          {loading && (
            <div className="flex items-center gap-2 px-4 py-3 text-sm text-text-muted">
              <div className="w-3.5 h-3.5 border-2 border-border-light border-t-sky-d rounded-full animate-spin shrink-0" />
              Mencari...
            </div>
          )}
          {!loading && results.length === 0 && query.length >= 2 && (
            <div className="px-4 py-3.5 text-sm text-text-muted text-center">Anime tidak ditemukan</div>
          )}
          {!loading && results.map((anime) => (
            <Link
              key={anime.animeId}
              href={`/anime/${anime.animeId}`}
              className="flex items-center gap-3 px-3.5 py-2.5 border-b border-border hover:bg-bg-tertiary transition-colors"
              onClick={() => setOpen(false)}
            >
              <div className="w-9 h-[50px] rounded-lg overflow-hidden shrink-0 relative bg-bg-tertiary">
                {anime.poster && (
                  <Image src={anime.poster} alt={anime.title} fill className="object-cover" sizes="36px" />
                )}
              </div>
              <div>
                <div className="text-[13px] font-bold line-clamp-1">{anime.title}</div>
                <div className="text-[11px] text-text-muted mt-0.5">
                  {anime.episodes} Eps {anime.releaseDay && `• ${anime.releaseDay}`}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
