'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import type { AnimeListItem } from '@/types';

const BANNER_THEMES = [
  'linear-gradient(135deg, #0f0c29, #302b63)',
  'linear-gradient(135deg, #0d324d, #7f5a83)',
  'linear-gradient(135deg, #134e5e, #71b280)',
  'linear-gradient(135deg, #c94b4b, #4b134f)',
];

interface Props {
  items: AnimeListItem[];
}

export default function BannerCarousel({ items }: Props) {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const touchStartX = useRef(0);
  const slides = items.slice(0, 4);

  const goTo = useCallback((idx: number) => {
    setCurrent(idx);
  }, []);

  useEffect(() => {
    if (slides.length <= 1) return;
    timerRef.current = setInterval(() => {
      setCurrent(prev => (prev + 1) % slides.length);
    }, 4200);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [slides.length]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 40) {
      const next = dx < 0
        ? (current + 1) % slides.length
        : (current - 1 + slides.length) % slides.length;
      goTo(next);
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setCurrent(prev => (prev + 1) % slides.length);
      }, 4200);
    }
  };

  if (slides.length === 0) return null;

  return (
    <div className="px-4 pt-4">
      <div
        className="rounded-2xl overflow-hidden relative"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <div
          className="flex transition-transform duration-500 ease-[cubic-bezier(0.77,0,0.18,1)]"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {slides.map((anime, i) => (
            <Link
              key={anime.animeId}
              href={`/anime/${anime.animeId}`}
              className="shrink-0 w-full relative overflow-hidden cursor-pointer"
              style={{ height: 'clamp(155px, 36vw, 210px)', background: BANNER_THEMES[i % BANNER_THEMES.length] }}
            >
              {anime.poster && (
                <Image
                  src={anime.poster}
                  alt={anime.title}
                  fill
                  className="object-cover opacity-40"
                  sizes="100vw"
                  priority={i === 0}
                />
              )}
              <div className="absolute w-[200px] h-[200px] rounded-full bg-white/5 -top-[60px] -right-[30px]" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/15 to-transparent" />
              
              {/* Score badge */}
              <div className="absolute top-3 right-3 z-10 bg-black/50 backdrop-blur-lg text-yellow text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1">
                <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 fill-yellow">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
                {anime.score || '—'}
              </div>

              <div className="absolute bottom-3.5 left-3.5 right-24 z-10">
                <span className="inline-block bg-sky-d text-white text-[9px] font-extrabold px-2 py-0.5 rounded tracking-wide uppercase mb-1.5">
                  {anime.releaseDay || 'Anime'}
                </span>
                <h3 className="text-[clamp(14px,4vw,18px)] font-extrabold text-white leading-tight mb-1.5 line-clamp-2 drop-shadow-lg">
                  {anime.title}
                </h3>
                <p className="text-[10.5px] text-white/65 mb-2.5">
                  {anime.episodes} Eps • Ongoing
                </p>
                <span className="inline-flex items-center gap-1.5 bg-yellow text-amber-900 text-xs font-extrabold px-3.5 py-1.5 rounded-full shadow-lg btn-press">
                  <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 fill-amber-900">
                    <polygon points="5 3 19 12 5 21 5 3"/>
                  </svg>
                  Tonton Sekarang
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Dots */}
      <div className="flex justify-center gap-1.5 mt-2.5">
        {slides.map((_, i) => (
          <button
            key={i}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              i === current ? 'w-5 bg-sky-d' : 'w-1.5 bg-border-light'
            }`}
            onClick={() => goTo(i)}
          />
        ))}
      </div>
    </div>
  );
}
