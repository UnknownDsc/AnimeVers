'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/components/AuthProvider';
import type { Comment } from '@/types';

interface Props { episodeId: string; }

export default function CommentSection({ episodeId }: Props) {
  const { user } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/comment?episodeId=${episodeId}`)
      .then(r => r.json())
      .then(d => setComments(d.comments || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [episodeId]);

  const handlePost = async () => {
    if (!content.trim() || posting) return;
    const token = localStorage.getItem('av_token');
    if (!token) return;
    setPosting(true);
    try {
      const res = await fetch('/api/comment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ episodeId, content: content.trim() }),
      });
      const data = await res.json();
      if (data.comment) { setComments(prev => [data.comment, ...prev]); setContent(''); }
    } catch { /* ignore */ }
    setPosting(false);
  };

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Baru saja';
    if (mins < 60) return `${mins}m lalu`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}j lalu`;
    return `${Math.floor(hours / 24)}h lalu`;
  };

  const avatarColors = [
    ['#0284C7','#38BDF8'], ['#8B5CF6','#06B6D4'], ['#0EA5E9','#10B981'],
    ['#F97316','#FACC15'], ['#10B981','#06B6D4'],
  ];

  return (
    <div className="mt-5" style={{ borderRadius: '14px', overflow: 'hidden', border: '1.5px solid rgba(255,255,255,0.06)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4"
        style={{ background: 'linear-gradient(135deg,rgba(14,165,233,.12),rgba(6,182,212,.08))', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white" strokeWidth="2.2" strokeLinecap="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </div>
          <span className="font-black text-base text-text-primary">Komentar</span>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full text-sky-d"
            style={{ background: 'rgba(14,165,233,.15)' }}>
            {comments.length}
          </span>
        </div>
      </div>

      <div className="bg-bg-secondary px-5 py-4">
        {/* Input area */}
        {user ? (
          <div className="mb-5 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="flex gap-3">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-[11px] font-black text-white shrink-0"
                style={{ background: 'linear-gradient(135deg,#0284C7,#38BDF8)' }}>
                {user.username.slice(0, 2).toUpperCase()}
              </div>
              <div className="flex-1">
                <textarea value={content} onChange={e => setContent(e.target.value)}
                  placeholder="Tulis komentar kamu di sini..."
                  maxLength={500}
                  className="w-full bg-bg-tertiary border border-border-light px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-muted outline-none resize-none h-[72px] transition-all focus:border-sky-d"
                  style={{ borderRadius: '10px' }} />
                <div className="flex justify-between items-center mt-2">
                  <span className="text-[10px] text-text-muted font-medium">{content.length}/500</span>
                  <button onClick={handlePost} disabled={!content.trim() || posting}
                    className="px-5 py-1.5 text-white text-xs font-black disabled:opacity-40 transition-all flex items-center gap-1.5"
                    style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)', borderRadius: '8px', boxShadow: '0 3px 12px rgba(14,165,233,.3)' }}>
                    {posting ? 'Mengirim...' : <>
                      Kirim
                      <svg viewBox="0 0 24 24" className="w-3 h-3 fill-none stroke-white" strokeWidth="2.5" strokeLinecap="round">
                        <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                      </svg>
                    </>}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="mb-5 p-4 rounded-xl text-center" style={{ background: 'rgba(14,165,233,.06)', border: '1px dashed rgba(14,165,233,.25)' }}>
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-sky-d mx-auto mb-2" strokeWidth="1.5" strokeLinecap="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
            </svg>
            <p className="text-sm text-text-muted mb-2">Login untuk bergabung dalam diskusi</p>
            <a href="/login" className="inline-flex items-center gap-1.5 px-4 py-1.5 text-white text-xs font-bold rounded-lg"
              style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
              Login Sekarang
              <svg viewBox="0 0 24 24" className="w-3 h-3 fill-none stroke-white" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </a>
          </div>
        )}

        {/* Comment list */}
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="flex gap-3 animate-pulse">
                <div className="w-9 h-9 rounded-lg skeleton shrink-0" />
                <div className="flex-1">
                  <div className="h-3 skeleton w-24 mb-2 rounded" />
                  <div className="h-12 skeleton rounded-lg" />
                </div>
              </div>
            ))}
          </div>
        ) : comments.length === 0 ? (
          <div className="py-8 text-center">
            <svg viewBox="0 0 24 24" className="w-10 h-10 fill-none stroke-text-muted mx-auto mb-3" strokeWidth="1.2" strokeLinecap="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            <p className="text-sm text-text-muted font-medium">Belum ada komentar</p>
            <p className="text-xs text-text-muted opacity-60 mt-1">Jadilah yang pertama berkomentar!</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {comments.map((c, idx) => {
              const [from, to] = avatarColors[idx % avatarColors.length];
              return (
                <div key={c.id} className="flex gap-3 animate-fade-in group">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center text-[10px] font-black text-white shrink-0"
                    style={{ background: `linear-gradient(135deg,${from},${to})` }}>
                    {(c.username || '?').slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 px-4 py-3 rounded-xl transition-all group-hover:border-border-light"
                    style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: '12px' }}>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-black text-sky-d">{c.username}</span>
                      <span className="w-1 h-1 rounded-full bg-text-muted opacity-40" />
                      <span className="text-[10px] text-text-muted">{timeAgo(c.created_at)}</span>
                    </div>
                    <p className="text-sm text-text-secondary leading-relaxed">{c.content}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
