'use client';

import { useState, useEffect } from 'react';
import type { Genre } from '@/types';

interface Props {
  onGenreSelect: (genreId: string) => void;
}

export default function GenreChips({ onGenreSelect }: Props) {
  const [genres, setGenres] = useState<Genre[]>([]);
  const [active, setActive] = useState('all');

  useEffect(() => {
    fetch('/api/anime/genre')
      .then(r => r.json())
      .then(d => {
        const list = d?.data?.genreList || [];
        setGenres(list);
      })
      .catch(() => {});
  }, []);

  const handleClick = (genreId: string) => {
    setActive(genreId);
    onGenreSelect(genreId);
  };

  return (
    <div className="px-4 pt-4">
      <h3 className="text-[15px] font-extrabold mb-2.5">Genres</h3>
      <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-0.5">
        <button
          onClick={() => handleClick('all')}
          className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-all border btn-press ${
            active === 'all'
              ? 'bg-sky-d border-sky-d text-white shadow-[0_3px_10px_rgba(14,165,233,0.28)]'
              : 'bg-transparent border-border-light text-text-secondary hover:border-sky-d hover:text-sky-d'
          }`}
        >
          Semua
        </button>
        {genres.slice(0, 15).map(g => (
          <button
            key={g.genreId}
            onClick={() => handleClick(g.genreId)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-all border btn-press ${
              active === g.genreId
                ? 'bg-sky-d border-sky-d text-white shadow-[0_3px_10px_rgba(14,165,233,0.28)]'
                : 'bg-transparent border-border-light text-text-secondary hover:border-sky-d hover:text-sky-d'
            }`}
          >
            {g.title}
          </button>
        ))}
      </div>
    </div>
  );
}
