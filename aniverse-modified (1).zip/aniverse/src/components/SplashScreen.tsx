'use client';

import { useEffect, useState } from 'react';

export default function SplashScreen() {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'loading' | 'done'>('loading');

  useEffect(() => {
    // Smooth progress animation
    const steps = [
      { target: 30, delay: 0,   dur: 400 },
      { target: 60, delay: 400, dur: 350 },
      { target: 85, delay: 750, dur: 300 },
      { target: 100,delay: 1100,dur: 300 },
    ];
    let timeouts: NodeJS.Timeout[] = [];
    steps.forEach(({ target, delay, dur }) => {
      const t = setTimeout(() => {
        const start = Date.now();
        const from = progress;
        const animate = () => {
          const elapsed = Date.now() - start;
          const p = Math.min(elapsed / dur, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          setProgress(Math.round(from + (target - from) * eased));
          if (p < 1) requestAnimationFrame(animate);
        };
        requestAnimationFrame(animate);
      }, delay);
      timeouts.push(t);
    });
    const done = setTimeout(() => setPhase('done'), 1500);
    return () => { timeouts.forEach(clearTimeout); clearTimeout(done); };
  }, []);

  const lines = ['Memuat konten anime...', 'Menyiapkan pengalaman terbaik...', 'Hampir selesai...'];
  const lineIdx = progress < 40 ? 0 : progress < 85 ? 1 : 2;

  return (
    <div
      className="fixed inset-0 z-[999] flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: '#070B14',
        opacity: phase === 'done' ? 0 : 1,
        transition: 'opacity 0.5s ease',
        pointerEvents: phase === 'done' ? 'none' : 'all',
      }}
    >
      {/* ── Ambient background orbs ─────────────────────────────────────── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Large glow */}
        <div style={{
          position: 'absolute', top: '20%', left: '50%', transform: 'translateX(-50%)',
          width: 600, height: 600, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(14,165,233,0.08) 0%, transparent 70%)',
          animation: 'splashPulse 3s ease-in-out infinite',
        }} />
        {/* Top-right orb */}
        <div style={{
          position: 'absolute', top: -60, right: -60, width: 300, height: 300, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(6,182,212,0.06) 0%, transparent 70%)',
          animation: 'splashFloat 5s ease-in-out infinite',
        }} />
        {/* Bottom-left orb */}
        <div style={{
          position: 'absolute', bottom: -80, left: -40, width: 350, height: 350, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(139,92,246,0.05) 0%, transparent 70%)',
          animation: 'splashFloat 6s ease-in-out infinite reverse 1s',
        }} />

        {/* Animated grid */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.025,
          backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }} />

        {/* Horizontal scan line */}
        <div style={{
          position: 'absolute', left: 0, right: 0, height: 1,
          background: 'linear-gradient(to right, transparent, rgba(14,165,233,0.3), transparent)',
          animation: 'scanLine 3s linear infinite',
        }} />
      </div>

      {/* ── Floating particles ──────────────────────────────────────────── */}
      {[...Array(12)].map((_, i) => (
        <div key={i} style={{
          position: 'absolute',
          width: i % 3 === 0 ? 4 : i % 3 === 1 ? 2.5 : 1.5,
          height: i % 3 === 0 ? 4 : i % 3 === 1 ? 2.5 : 1.5,
          borderRadius: '50%',
          background: i % 2 === 0 ? 'rgba(14,165,233,0.5)' : 'rgba(6,182,212,0.4)',
          left: `${8 + (i * 7.5) % 84}%`,
          top: `${15 + (i * 13) % 70}%`,
          animation: `particle${i % 4} ${3 + (i % 3)}s ease-in-out infinite ${i * 0.3}s`,
        }} />
      ))}

      {/* ── Center content ──────────────────────────────────────────────── */}
      <div className="relative z-10 flex flex-col items-center" style={{ animation: 'splashFadeIn 0.6s ease both' }}>

        {/* Logo icon */}
        <div style={{
          width: 80, height: 80, borderRadius: 24,
          background: 'linear-gradient(135deg, #0284C7 0%, #0EA5E9 50%, #06B6D4 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 20,
          boxShadow: '0 0 0 1px rgba(14,165,233,0.3), 0 20px 60px rgba(14,165,233,0.35), 0 0 80px rgba(14,165,233,0.15)',
          animation: 'logoBreath 2.5s ease-in-out infinite',
        }}>
          {/* Play icon */}
          <svg viewBox="0 0 24 24" style={{ width: 40, height: 40, fill: 'white', filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.4))' }}>
            <path d="M8 5.14v14l11-7-11-7z"/>
          </svg>
        </div>

        {/* Brand name */}
        <div style={{
          fontSize: 36, fontWeight: 900, letterSpacing: '-0.02em', lineHeight: 1,
          background: 'linear-gradient(135deg, #F8FAFC 0%, #38BDF8 50%, #06B6D4 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          marginBottom: 6,
          fontFamily: 'var(--font-jakarta)',
        }}>
          AniVerse
        </div>
        <div style={{
          fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.25)', fontWeight: 600, marginBottom: 44,
        }}>
          Streaming Tanpa Batas
        </div>

        {/* Progress bar */}
        <div style={{ width: 220, marginBottom: 14 }}>
          {/* Track */}
          <div style={{
            height: 3, borderRadius: 99, background: 'rgba(255,255,255,0.06)',
            overflow: 'hidden', position: 'relative',
          }}>
            {/* Fill */}
            <div style={{
              position: 'absolute', inset: 0, borderRadius: 99,
              background: 'linear-gradient(to right, #0284C7, #0EA5E9, #06B6D4)',
              width: `${progress}%`,
              transition: 'width 0.3s ease',
              boxShadow: '0 0 8px rgba(14,165,233,0.6)',
            }} />
            {/* Shimmer */}
            <div style={{
              position: 'absolute', top: 0, bottom: 0,
              width: '40%',
              background: 'linear-gradient(to right, transparent, rgba(255,255,255,0.3), transparent)',
              animation: 'shimmerBar 1.5s linear infinite',
            }} />
          </div>

          {/* Labels */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
            <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.25)', letterSpacing: '0.05em' }}>
              {lines[lineIdx]}
            </span>
            <span style={{
              fontSize: 10, fontWeight: 800, fontFamily: 'monospace',
              background: 'linear-gradient(to right,#38BDF8,#06B6D4)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>
              {progress}%
            </span>
          </div>
        </div>

        {/* Dot indicators */}
        <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
          {[0, 1, 2].map(i => (
            <div key={i} style={{
              width: 5, height: 5, borderRadius: '50%',
              background: 'rgba(14,165,233,0.6)',
              animation: `dotBounce 1.2s ease-in-out infinite ${i * 0.18}s`,
            }} />
          ))}
        </div>
      </div>

      {/* ── Version badge ────────────────────────────────────────────────── */}
      <div style={{
        position: 'absolute', bottom: 28, left: '50%', transform: 'translateX(-50%)',
        fontSize: 9, color: 'rgba(255,255,255,0.12)', letterSpacing: '0.15em',
        textTransform: 'uppercase', fontWeight: 600, whiteSpace: 'nowrap',
      }}>
        v2.0.0 · Built with Next.js
      </div>

      {/* ── Keyframes ───────────────────────────────────────────────────── */}
      <style>{`
        @keyframes splashFadeIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        @keyframes splashPulse  { 0%,100%{opacity:0.6; transform:translateX(-50%) scale(1);} 50%{opacity:1; transform:translateX(-50%) scale(1.08);} }
        @keyframes splashFloat  { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-18px);} }
        @keyframes scanLine     { 0%{top:-2px; opacity:0;} 10%{opacity:1;} 90%{opacity:1;} 100%{top:100%; opacity:0;} }
        @keyframes logoBreath   { 0%,100%{box-shadow:0 0 0 1px rgba(14,165,233,0.3),0 20px 60px rgba(14,165,233,0.35),0 0 80px rgba(14,165,233,0.15);} 50%{box-shadow:0 0 0 1px rgba(14,165,233,0.5),0 20px 80px rgba(14,165,233,0.5),0 0 120px rgba(14,165,233,0.25);} }
        @keyframes shimmerBar   { 0%{left:-40%;} 100%{left:100%;} }
        @keyframes dotBounce    { 0%,100%{opacity:.25;transform:translateY(0) scale(0.8);} 50%{opacity:1;transform:translateY(-6px) scale(1.2);} }
        @keyframes particle0    { 0%,100%{transform:translateY(0) scale(1);opacity:0.4;} 50%{transform:translateY(-20px) scale(1.2);opacity:0.8;} }
        @keyframes particle1    { 0%,100%{transform:translateY(0) translateX(0);opacity:0.3;} 50%{transform:translateY(-14px) translateX(8px);opacity:0.7;} }
        @keyframes particle2    { 0%,100%{transform:translateY(0) scale(1);opacity:0.5;} 33%{transform:translateY(-10px) scale(0.8);opacity:0.2;} 66%{transform:translateY(-24px) scale(1.1);opacity:0.9;} }
        @keyframes particle3    { 0%,100%{transform:translateX(0);opacity:0.3;} 50%{transform:translateX(-12px);opacity:0.7;} }
      `}</style>
    </div>
  );
}
