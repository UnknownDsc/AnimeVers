'use client';

import Link from 'next/link';
import Image from 'next/image';
import { GRADIENT_PALETTES } from '@/lib/constants';
import type { AnimeListItem } from '@/types';

interface Props {
  anime: AnimeListItem;
  index: number;
  badge?: string;
}

export default function AnimeCard({ anime, index, badge }: Props) {
  const g = GRADIENT_PALETTES[index % GRADIENT_PALETTES.length];
  const gradient = `linear-gradient(135deg, ${g[0]}, ${g[1]})`;

  return (
    <Link
      href={`/anime/${anime.animeId}`}
      className="shrink-0 w-[clamp(108px,27vw,136px)] cursor-pointer animate-fade-in"
      style={{ animationDelay: `${index * 0.04}s` }}
    >
      <div className="w-full aspect-[3/4] rounded-xl relative overflow-hidden card-hover" style={{ background: gradient }}>
        {/* Decorative shapes */}
        <div className="absolute w-[130px] h-[130px] rounded-full bg-white/10 -top-[50px] -right-[35px]" />
        <div className="absolute w-[70px] h-[70px] rounded-full bg-white/5 bottom-[25px] -left-5" />
        
        {/* Poster image */}
        {anime.poster && (
          <Image
            src={anime.poster}
            alt={anime.title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 27vw, 136px"
            loading="lazy"
          />
        )}

        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-[65%] bg-gradient-to-t from-black/90 to-transparent" />

        {/* Rating */}
        {anime.score && (
          <div className="absolute top-1.5 left-1.5 z-10 bg-black/50 backdrop-blur-md text-yellow text-[9.5px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1">
            <svg viewBox="0 0 24 24" className="w-[9px] h-[9px] fill-yellow">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
            {anime.score}
          </div>
        )}

        {/* Badge */}
        {badge && (
          <div className={`absolute top-1.5 right-1.5 z-10 text-[8px] font-extrabold tracking-wide uppercase px-1.5 py-0.5 rounded ${
            badge === 'NEW' ? 'bg-mint text-white' :
            badge === 'HOT' ? 'bg-red text-white' :
            'bg-yellow text-amber-900'
          }`}>
            {badge}
          </div>
        )}

        {/* Title on poster */}
        <div className="absolute bottom-1.5 left-1.5 right-1.5 z-10 text-[10.5px] font-bold text-white leading-tight line-clamp-2">
          {anime.title}
        </div>
      </div>

      <div className="mt-1.5 px-0.5">
        <div className="text-[12.5px] font-bold truncate">{anime.title}</div>
        <div className="text-[10.5px] text-text-muted mt-0.5">
          {anime.episodes} Eps {anime.releaseDay && `• ${anime.releaseDay}`}
        </div>
      </div>
    </Link>
  );
}

export function AnimeCardSkeleton() {
  return (
    <div className="shrink-0 w-[clamp(108px,27vw,136px)]">
      <div className="w-full aspect-[3/4] skeleton rounded-xl" />
      <div className="mt-1.5">
        <div className="h-3 skeleton w-full mb-1.5" />
        <div className="h-2.5 skeleton w-3/5" />
      </div>
    </div>
  );
}
