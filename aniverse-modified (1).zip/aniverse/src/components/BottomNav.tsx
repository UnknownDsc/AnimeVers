'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const tabs = [
  { href: '/', label: 'Home', icon: (
    <svg viewBox="0 0 24 24" className="w-[22px] h-[22px]"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
  )},
  { href: '/search', label: 'Search', icon: (
    <svg viewBox="0 0 24 24" className="w-[22px] h-[22px]"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
  )},
  { href: '/history', label: 'History', icon: (
    <svg viewBox="0 0 24 24" className="w-[22px] h-[22px]"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
  )},
  { href: '/favorites', label: 'Favorit', icon: (
    <svg viewBox="0 0 24 24" className="w-[22px] h-[22px]"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
  )},
  { href: '/profile', label: 'Profil', icon: (
    <svg viewBox="0 0 24 24" className="w-[22px] h-[22px]"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
  )},
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-[100] glass border-t border-white/[0.05] min-h-[72px] pb-[env(safe-area-inset-bottom)] flex items-center justify-around px-2">
      {tabs.map(tab => {
        const isActive = tab.href === '/' ? pathname === '/' : pathname.startsWith(tab.href);
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className="flex flex-col items-center justify-center gap-1.5 flex-1 h-full py-2 relative btn-press group"
          >
            {isActive && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-sky-d rounded-b-full shadow-[0_0_12px_#0EA5E9]" />
            )}
            <span className={`fill-none stroke-2 stroke-linecap-round stroke-linejoin-round transition-all duration-300 ${isActive ? 'stroke-sky-d scale-110' : 'stroke-text-muted group-hover:stroke-text-secondary'}`}>
              {tab.icon}
            </span>
            <span className={`text-[10px] font-bold tracking-tight transition-colors ${isActive ? 'text-sky-d' : 'text-text-muted'}`}>
              {tab.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
