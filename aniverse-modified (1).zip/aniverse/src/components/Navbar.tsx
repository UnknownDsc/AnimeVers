'use client';

import { useAuth } from '@/components/AuthProvider';
import { getRank, getXpProgress } from '@/lib/constants';
import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Navbar() {
  const { user, isAdmin } = useAuth();
  const [notifCount, setNotifCount] = useState(0);
  const [showRankModal, setShowRankModal] = useState(false);

  const rank = getRank(user?.level || 1);
  const xpPct = getXpProgress(user?.xp || 0);
  const initial = (user?.username || '?').slice(0, 2).toUpperCase();

  useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('av_token');
    if (!token) return;

    const fetchNotifs = () => {
      fetch('/api/notifications', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(d => {
          if (d.unreadCount !== undefined) setNotifCount(d.unreadCount);
        })
        .catch(() => {});
    };

    fetchNotifs();
    const interval = setInterval(fetchNotifs, 60000); // Poll every 60s
    return () => clearInterval(interval);
  }, [user]);

  const RANKS = [
    { minLv: 0, name: 'Newbie', color: '#94A3B8', bg: '#1E293B', emoji: 'N' },
    { minLv: 10, name: 'Beginner', color: '#0EA5E9', bg: '#0C4A6E', emoji: 'B' },
    { minLv: 25, name: 'Watcher', color: '#8B5CF6', bg: '#3B0764', emoji: 'W' },
    { minLv: 50, name: 'Otaku', color: '#F59E0B', bg: '#78350F', emoji: 'O' },
    { minLv: 75, name: 'Senpai', color: '#10B981', bg: '#064E3B', emoji: 'S' },
    { minLv: 100, name: 'Anime Master', color: '#EF4444', bg: '#7F1D1D', emoji: 'M' },
  ];

  return (
    <>
      <header className="sticky top-0 z-50 glass border-b border-border h-[62px] flex items-center px-4 gap-3">
        {/* Brand Logo */}
        <Link href="/" className="flex items-center shrink-0 mr-1.5 btn-press">
          <img src="/logo.png" alt="AniVerse" className="h-8 w-auto object-contain" />
        </Link>
        
        {/* Rank Pill */}
        <button
          onClick={() => setShowRankModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11.5px] font-extrabold text-white cursor-pointer btn-press shrink-0"
          style={{ background: `linear-gradient(135deg, ${rank.color}, #F59E0B)`, boxShadow: `0 3px 10px ${rank.color}50` }}
        >
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-white"><path d="M2 19L5 9l5 4 2-6 2 6 5-4 3 10H2z"/></svg>
          {rank.name}
        </button>

        {/* User Block */}
        <Link href="/profile" className="flex items-center gap-2.5 flex-1 min-w-0">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-extrabold text-white shrink-0 border-2"
            style={{ background: `linear-gradient(135deg, ${rank.color}, #0284C7)`, borderColor: rank.color }}
          >
            {initial}
          </div>
          <div className="min-w-0">
            <div className="text-[12px] sm:text-[13px] font-bold truncate">{user?.username || '—'}</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span
                className="text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0"
                style={{ color: rank.color, background: `${rank.color}15` }}
              >
                Lv.{user?.level || 1}
              </span>
              <div className="flex-1 max-w-[54px] h-1 bg-border-light rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${xpPct}%`, background: `linear-gradient(90deg, ${rank.color}, #0EA5E9)` }}
                />
              </div>
              <span className="text-[9px] text-text-muted shrink-0">{Math.round(xpPct)}%</span>
            </div>
          </div>
        </Link>

        {/* Admin button */}
        {isAdmin && (
          <Link href="/admin" className="w-9 h-9 rounded-full bg-yellow/15 border border-yellow/30 flex items-center justify-center shrink-0 btn-press" title="Admin Dashboard">
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          </Link>
        )}

        {/* Notification Bell */}
        <Link href="/notifications" className="relative w-9 h-9 rounded-full bg-bg-tertiary border border-border-light flex items-center justify-center shrink-0 btn-press">
          <svg viewBox="0 0 24 24" className="w-[18px] h-[18px] fill-none stroke-text-secondary" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
          {notifCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red text-white text-[8.5px] font-extrabold flex items-center justify-center border-2 border-bg-primary">
              {notifCount > 9 ? '9+' : notifCount}
            </span>
          )}
        </Link>
      </header>

      {/* Rank Modal */}
      {showRankModal && (
        <div className="fixed inset-0 z-[100] flex items-end" onClick={() => setShowRankModal(false)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div className="relative w-full bg-bg-secondary rounded-t-3xl p-5 max-h-[80vh] overflow-y-auto animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-border-light rounded-full mx-auto mb-5" />
            <h2 className="text-xl font-extrabold mb-1">Upgrade Rank</h2>
            <p className="text-sm text-text-muted mb-5">Tonton lebih banyak anime untuk naik rank!</p>
            <div className="flex flex-col gap-3">
              {RANKS.map((r, i) => {
                const unlocked = (user?.level || 1) >= r.minLv;
                const next = RANKS[i + 1];
                const isCurrent = unlocked && (!next || (user?.level || 1) < next.minLv);
                return (
                  <div
                    key={r.name}
                    className="flex items-center gap-3.5 p-3.5 rounded-2xl border transition-colors"
                    style={{
                      borderColor: isCurrent ? r.color : 'var(--color-border-light)',
                      background: isCurrent ? `${r.color}10` : 'transparent',
                    }}
                  >
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: `${r.color}20` }}>
                      {r.emoji}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-bold" style={{ color: r.color }}>
                        {r.name} {isCurrent && '(Kamu)'}
                      </div>
                      <div className="text-[11.5px] text-text-muted mt-0.5">
                        Min Level {r.minLv}
                        {unlocked && <span className="text-mint font-bold ml-1">✓ Terbuka</span>}
                      </div>
                    </div>
                    {unlocked && (
                      <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0" fill="none" stroke={r.color} strokeWidth="2.5" strokeLinecap="round">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
