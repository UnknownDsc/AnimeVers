'use client';

import { useState, useEffect, useRef } from 'react';

interface Props {
  streamingUrl: string;
  episodeId: string;
  onXpEarned?: () => void;
  onProgress?: (pct: number) => void;
}

export default function VideoPlayer({ streamingUrl, episodeId, onXpEarned, onProgress }: Props) {
  const [watchTime, setWatchTime] = useState(0);
  const [progress, setProgress] = useState(0);
  const [xpMessage, setXpMessage] = useState('');
  const [isClaiming, setIsClaiming] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(Date.now());
  const lastUpdateRef = useRef<number>(0);

  const resetTimer = () => {
    startTimeRef.current = Date.now();
    setWatchTime(0); setProgress(0); lastUpdateRef.current = 0;
  };

  const getEmbedUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('youtube.com/watch?v=')) {
      const id = url.split('v=')[1]?.split('&')[0];
      return `https://www.youtube.com/embed/${id}?autoplay=1&mute=1&rel=0`;
    }
    if (url.includes('youtu.be/')) {
      const id = url.split('youtu.be/')[1]?.split('?')[0];
      return `https://www.youtube.com/embed/${id}?autoplay=1&mute=1&rel=0`;
    }
    return url;
  };

  const embedUrl = getEmbedUrl(streamingUrl);

  useEffect(() => {
    resetTimer();
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      setWatchTime(elapsed);
      const prog = Math.min((elapsed / 1440) * 100, 100);
      setProgress(prog);
      if (elapsed - lastUpdateRef.current >= 15) {
        onProgress?.(Math.round(prog));
        lastUpdateRef.current = elapsed;
      }
    }, 1000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [episodeId, streamingUrl, onProgress]);

  useEffect(() => {
    if (watchTime >= 300 && !isClaiming) handleClaimXP();
  }, [watchTime, isClaiming]);

  const handleClaimXP = async () => {
    setIsClaiming(true);
    const token = localStorage.getItem('av_token');
    if (!token) { setIsClaiming(false); return; }
    try {
      const res = await fetch('/api/xp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ episodeId, watchTime, progress: Math.round(progress) || 100 }),
      });
      const data = await res.json();
      if (data.xp !== undefined) {
        setXpMessage(data.message || '+10 XP!');
        setShowConfetti(true);
        onXpEarned?.();
        setTimeout(() => { setXpMessage(''); setShowConfetti(false); resetTimer(); setIsClaiming(false); }, 4000);
      } else { setIsClaiming(false); }
    } catch { setIsClaiming(false); }
  };

  return (
    <div className="relative">
      {/* Video container — sharp rectangle */}
      <div className="w-full aspect-video bg-black overflow-hidden relative border border-white/10"
        style={{ borderRadius: '12px', boxShadow: '0 8px 40px rgba(0,0,0,.6)' }}>
        <iframe src={embedUrl} className="w-full h-full border-0" allowFullScreen allow="autoplay; encrypted-media" />

        {isClaiming && !showConfetti && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-10">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-4 border-sky-d/30 border-t-sky-d rounded-full animate-spin" />
              <p className="text-white font-bold text-sm tracking-widest animate-pulse">CLAIMING XP...</p>
            </div>
          </div>
        )}
      </div>

      {/* XP confetti overlay */}
      {showConfetti && (
        <div className="fixed inset-0 z-[200] pointer-events-none flex items-center justify-center overflow-hidden">
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={i} className="absolute w-2 h-2 rounded-sm animate-ping"
              style={{ left: `${Math.random()*100}%`, top: `${Math.random()*100}%`, animationDelay: `${Math.random()*2}s`, background: ['#38BDF8','#06B6D4','#10B981','#FACC15'][i%4] }} />
          ))}
          <div className="bg-gradient-to-br from-[#0EA5E9] to-[#06B6D4] text-white px-8 py-5 font-black text-lg shadow-[0_20px_50px_rgba(14,165,233,0.5)] border-2 border-white/30 animate-bounce flex flex-col items-center gap-1"
            style={{ borderRadius: '16px', transform: 'scale(1.4)' }}>
            <svg viewBox="0 0 24 24" className="w-10 h-10 fill-yellow-300 stroke-yellow-400 stroke-1 mb-1">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
            {xpMessage}
            <span className="text-xs opacity-80 uppercase mt-1 tracking-widest">Level Up Soon!</span>
          </div>
        </div>
      )}
    </div>
  );
}
