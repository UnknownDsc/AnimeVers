'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';
import BottomNav from '@/components/BottomNav';

interface Notification {
  id: string;
  message: string;
  anime_id: string | null;
  is_read: boolean;
  created_at: string;
}

export default function NotificationsPage() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('av_token');
    if (!token) return;

    fetch('/api/notifications', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(r => r.json())
      .then(d => {
        setNotifications(d.notifications || []);
        // Mark all as read when opening page
        fetch('/api/notifications', {
          method: 'PATCH',
          headers: { 
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}` 
          },
          body: JSON.stringify({})
        }).catch(() => {});
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user]);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return new Intl.RelativeTimeFormat('id', { numeric: 'auto' }).format(
      Math.round((date.getTime() - Date.now()) / (1000 * 60 * 60 * 24)), 
      'day'
    );
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-6">
          <Link href="/" className="w-10 h-10 rounded-2xl bg-bg-secondary border border-border-light flex items-center justify-center btn-press">
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-text-primary" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 18l-6-6 6-6"/>
            </svg>
          </Link>
          <div>
            <h1 className="text-xl font-black text-white leading-none">Notifikasi</h1>
            <p className="text-xs text-text-muted mt-1">Pesan terbaru dari sistem & admin</p>
          </div>
        </div>

        {/* Content */}
        <div className="px-4 space-y-3">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-20 skeleton rounded-2xl" />
            ))
          ) : notifications.length > 0 ? (
            notifications.map((n) => (
              <div 
                key={n.id} 
                className={`p-4 rounded-2xl border transition-all ${
                  n.is_read ? 'bg-bg-secondary/30 border-white/5' : 'bg-sky-d/10 border-sky-d/20'
                }`}
              >
                <div className="flex gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    n.is_read ? 'bg-bg-tertiary text-text-muted' : 'bg-sky-d text-white shadow-lg shadow-sky-d/20'
                  }`}>
                    {n.anime_id 
  ? <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><rect x="2" y="2" width="20" height="20" rx="4"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
  : <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><path d="M22 17H2a3 3 0 0 0 3-3V9a7 7 0 0 1 14 0v5a3 3 0 0 0 3 3z"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm leading-relaxed ${n.is_read ? 'text-text-secondary' : 'text-white font-medium'}`}>
                      {n.message}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[10px] text-text-muted">{formatDate(n.created_at)}</span>
                      {n.anime_id && (
                        <Link 
                          href={`/anime/${n.anime_id}`}
                          className="text-[10px] font-bold text-sky-d hover:sky-l"
                        >
                          Lihat Anime →
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="py-20 text-center">
              <div className="text-5xl mb-4 opacity-30">📭</div>
              <p className="text-sm text-text-muted">Belum ada notifikasi baru untukmu.</p>
            </div>
          )}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
