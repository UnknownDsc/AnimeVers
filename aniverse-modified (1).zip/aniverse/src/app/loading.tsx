// Next.js route-level loading UI (shown between page transitions)
export default function Loading() {
  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: '#070B14',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 0,
      }}
    >
      {/* Top progress bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: 'rgba(255,255,255,0.05)',
        overflow: 'hidden',
      }}>
        <div style={{
          height: '100%',
          background: 'linear-gradient(to right, #0284C7, #0EA5E9, #06B6D4)',
          animation: 'topBarLoad 1.6s ease-in-out infinite',
          boxShadow: '0 0 10px rgba(14,165,233,0.8)',
        }} />
      </div>

      {/* Ambient glow */}
      <div style={{
        position: 'absolute', top: '30%', left: '50%', transform: 'translateX(-50%)',
        width: 400, height: 400, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(14,165,233,0.07) 0%, transparent 70%)',
        animation: 'glowPulse 2.5s ease-in-out infinite',
        pointerEvents: 'none',
      }} />

      {/* Grid */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.02,
        backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)',
        backgroundSize: '40px 40px',
        pointerEvents: 'none',
      }} />

      {/* Logo + spinner */}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 32 }}>
        {/* Outer ring */}
        <div style={{
          position: 'absolute',
          width: 88, height: 88, borderRadius: '50%',
          border: '2px solid rgba(14,165,233,0.15)',
          animation: 'ringRotate 3s linear infinite',
        }}>
          <div style={{
            position: 'absolute', top: -3, left: '50%', transform: 'translateX(-50%)',
            width: 6, height: 6, borderRadius: '50%',
            background: '#0EA5E9', boxShadow: '0 0 8px #0EA5E9',
          }} />
        </div>
        {/* Inner ring */}
        <div style={{
          position: 'absolute',
          width: 70, height: 70, borderRadius: '50%',
          border: '1.5px solid rgba(6,182,212,0.1)',
          animation: 'ringRotate 2s linear infinite reverse',
        }}>
          <div style={{
            position: 'absolute', bottom: -2, left: '50%', transform: 'translateX(-50%)',
            width: 4, height: 4, borderRadius: '50%',
            background: '#06B6D4', boxShadow: '0 0 6px #06B6D4',
          }} />
        </div>

        {/* Logo box */}
        <div style={{
          width: 52, height: 52, borderRadius: 16,
          background: 'linear-gradient(135deg,#0284C7,#0EA5E9,#06B6D4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 30px rgba(14,165,233,0.3)',
          animation: 'logoPulse 2s ease-in-out infinite',
        }}>
          <svg viewBox="0 0 24 24" style={{ width: 26, height: 26, fill: 'white' }}>
            <path d="M8 5.14v14l11-7-11-7z"/>
          </svg>
        </div>
      </div>

      {/* Brand */}
      <div style={{
        fontSize: 22, fontWeight: 900, letterSpacing: '-0.02em',
        background: 'linear-gradient(135deg,#F8FAFC,#38BDF8,#06B6D4)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        marginBottom: 6, fontFamily: 'var(--font-jakarta)',
      }}>
        AniVerse
      </div>

      {/* Dots */}
      <div style={{ display: 'flex', gap: 5 }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            width: 5, height: 5, borderRadius: '50%',
            background: 'linear-gradient(to right,#0EA5E9,#06B6D4)',
            animation: `dotJump 1s ease-in-out infinite ${i*0.15}s`,
          }} />
        ))}
      </div>

      <style>{`
        @keyframes topBarLoad   { 0%{width:0%;margin-left:0} 50%{width:70%;margin-left:0} 100%{width:0%;margin-left:100%} }
        @keyframes glowPulse    { 0%,100%{opacity:.6; transform:translateX(-50%) scale(1);} 50%{opacity:1; transform:translateX(-50%) scale(1.1);} }
        @keyframes ringRotate   { to{transform:rotate(360deg);} }
        @keyframes logoPulse    { 0%,100%{box-shadow:0 0 30px rgba(14,165,233,.3);} 50%{box-shadow:0 0 50px rgba(14,165,233,.5), 0 0 80px rgba(14,165,233,.2);} }
        @keyframes dotJump      { 0%,100%{transform:translateY(0);opacity:.3;} 50%{transform:translateY(-7px);opacity:1;} }
      `}</style>
    </div>
  );
}
