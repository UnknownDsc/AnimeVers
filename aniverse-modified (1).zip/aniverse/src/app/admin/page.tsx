'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/components/AuthProvider';
import Link from 'next/link';
import type { UserPublic, Comment, AdminLog } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────
type Tab = 'overview' | 'users' | 'comments' | 'broadcast' | 'logs' | 'security' | 'maintenance';

interface Stats {
  totalUsers: number; totalAdmins: number; totalBanned: number;
  totalComments: number; totalFavorites: number; totalXpLogs: number;
  recentUsers: UserPublic[]; recentComments: (Comment & { username?: string })[];
}
interface UserRow {
  id: string; username: string; role: string; xp: number; level: number;
  title: string; is_banned: boolean; ban_reason?: string; created_at: string;
}
interface SecurityEvent { id: string; type: string; detail: string; ts: number; }

// ─── Security constants ───────────────────────────────────────────────────────
const SESSION_TIMEOUT = 15 * 60 * 1000; // 15 min inactivity
const ACTION_COOLDOWN  = 1500;           // ms between admin actions
const MAX_ACTIONS_PER_MIN = 20;

// ─── Helpers ─────────────────────────────────────────────────────────────────
function api(path: string, opts?: RequestInit) {
  const token = typeof window !== 'undefined' ? localStorage.getItem('av_token') : null;
  return fetch(path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      'X-Admin-Nonce': Date.now().toString(36),
      ...(opts?.headers || {}),
    },
  });
}

function timeAgo(d: string) {
  const diff = Date.now() - new Date(d).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'Baru';
  if (m < 60) return `${m}m lalu`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}j lalu`;
  return `${Math.floor(h / 24)}h lalu`;
}

// ─── SVG Icon Component ───────────────────────────────────────────────────────
function Icon({ name, cls = 'w-5 h-5' }: { name: string; cls?: string }) {
  const p: Record<string, React.ReactNode> = {
    home: <><rect x="3" y="11" width="18" height="10" rx="1"/><polyline points="3 11 12 3 21 11"/></>,
    users: <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
    chat:  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>,
    bell:  <><path d="M22 17H2a3 3 0 0 0 3-3V9a7 7 0 0 1 14 0v5a3 3 0 0 0 3 3z"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></>,
    log:   <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></>,
    shield:<><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></>,
    tool:  <><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></>,
    lock:  <><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></>,
    ban:   <><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></>,
    check: <polyline points="20 6 9 17 4 12"/>,
    trash: <><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6M9 6V4h6v2"/></>,
    key:   <><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/></>,
    xp:    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>,
    alert: <><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>,
    heart: <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>,
    game:  <><line x1="6" y1="12" x2="18" y2="12"/><line x1="12" y1="6" x2="12" y2="18"/><circle cx="12" cy="12" r="10"/></>,
    eye:   <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>,
    down:  <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
    send:  <><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></>,
    clock: <><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></>,
    arrow: <path d="M5 12h14M12 5l7 7-7 7"/>,
    crown: <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>,
    refresh: <><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></>,
    search: <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    filter: <><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></>,
  };
  return (
    <svg viewBox="0 0 24 24" className={`${cls} fill-none stroke-current`} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {p[name]}
    </svg>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ value, label, icon, color, sub }: { value: number | string; label: string; icon: string; color: string; sub?: string }) {
  return (
    <div className="relative rounded-2xl p-4 overflow-hidden border border-white/5"
      style={{ background: 'linear-gradient(135deg,rgba(255,255,255,0.04),rgba(255,255,255,0.01))' }}>
      <div className="absolute inset-0 opacity-10 rounded-2xl" style={{ background: `radial-gradient(circle at top right, ${color}, transparent 70%)` }} />
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-2xl font-black mt-1" style={{ color }}>{value ?? '—'}</div>
          <div className="text-xs font-semibold text-white/50 mt-0.5">{label}</div>
          {sub && <div className="text-[10px] text-white/30 mt-0.5">{sub}</div>}
        </div>
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}22` }}>
          <Icon name={icon} cls="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}

// ─── Confirm Modal (typed confirmation for destructive actions) ────────────────
function ConfirmModal({ target, action, onConfirm, onClose }: {
  target: string; action: string; onConfirm: () => void; onClose: () => void;
}) {
  const [typed, setTyped] = useState('');
  const required = target.toUpperCase();
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative rounded-2xl p-6 w-full max-w-sm shadow-2xl border border-red/30 animate-slide-up"
        style={{ background: '#12101a' }}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red/20 flex items-center justify-center text-red">
            <Icon name="alert" cls="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-sm text-white">Konfirmasi Tindakan</h3>
            <p className="text-[11px] text-white/40">Tindakan ini tidak dapat dibatalkan</p>
          </div>
        </div>
        <div className="bg-red/10 border border-red/20 rounded-xl px-4 py-3 mb-4">
          <p className="text-sm text-white/80">Ketik <strong className="text-red font-black">{required}</strong> untuk {action}:</p>
        </div>
        <input type="text" value={typed} onChange={e => setTyped(e.target.value.toUpperCase())}
          placeholder={`Ketik ${required}...`}
          className="w-full bg-white/5 border-2 border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-red mb-4 font-mono tracking-widest" />
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 bg-white/5 text-white/60 text-sm font-bold rounded-xl hover:bg-white/10 transition">Batal</button>
          <button onClick={onConfirm} disabled={typed !== required}
            className="flex-1 py-2.5 bg-red text-white text-sm font-black rounded-xl disabled:opacity-30 disabled:cursor-not-allowed transition">
            Konfirmasi
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const { user, isAdmin } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [usersTotal, setUsersTotal] = useState(0);
  const [usersPage, setUsersPage] = useState(1);
  const [usersSearch, setUsersSearch] = useState('');
  const [usersFilter, setUsersFilter] = useState('');
  const [comments, setComments] = useState<(Comment & { username?: string })[]>([]);
  const [commentsTotal, setCommentsTotal] = useState(0);
  const [commentsPage, setCommentsPage] = useState(1);
  const [logs, setLogs] = useState<AdminLog[]>([]);
  const [logsTotal, setLogsTotal] = useState(0);
  const [logsPage, setLogsPage] = useState(1);
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [broadcastType, setBroadcastType] = useState<'info' | 'warning' | 'success'>('info');
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ msg: '', type: '' });
  const [modal, setModal] = useState<{ type: string; user?: UserRow; extra?: string } | null>(null);
  const [modalInput, setModalInput] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<{ userId: string; username: string } | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Security state
  const [sessionTimeLeft, setSessionTimeLeft] = useState(SESSION_TIMEOUT);
  const [actionCount, setActionCount] = useState(0);
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [isLocked, setIsLocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [adminPin] = useState(() => typeof window !== 'undefined' ? (localStorage.getItem('av_admin_pin') || '') : '');
  const [pinSetInput, setPinSetInput] = useState('');
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  const lastActionRef = useRef<number>(0);
  const actionCounterRef = useRef<{ count: number; reset: NodeJS.Timeout | null }>({ count: 0, reset: null });
  const sessionTimerRef = useRef<NodeJS.Timeout | null>(null);
  const activityRef = useRef<number>(Date.now());

  // ── Security: session timeout ────────────────────────────────────────────────
  const resetSession = useCallback(() => {
    activityRef.current = Date.now();
    setSessionTimeLeft(SESSION_TIMEOUT);
    setIsLocked(false);
  }, []);

  useEffect(() => {
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(e => window.addEventListener(e, resetSession, { passive: true }));
    const tick = setInterval(() => {
      const idle = Date.now() - activityRef.current;
      const left = Math.max(0, SESSION_TIMEOUT - idle);
      setSessionTimeLeft(left);
      if (left === 0) setIsLocked(true);
    }, 5000);
    return () => { events.forEach(e => window.removeEventListener(e, resetSession)); clearInterval(tick); };
  }, [resetSession]);

  // ── Security: rate limiting ──────────────────────────────────────────────────
  const rateCheck = (): boolean => {
    const now = Date.now();
    if (now - lastActionRef.current < ACTION_COOLDOWN) {
      addSecurityEvent('rate_limit', 'Too many actions too fast');
      showToast('Terlalu cepat! Tunggu sebentar.', 'err');
      return false;
    }
    actionCounterRef.current.count++;
    if (actionCounterRef.current.count > MAX_ACTIONS_PER_MIN) {
      addSecurityEvent('flood', `Action flood: ${actionCounterRef.current.count} actions/min`);
      showToast('Terlalu banyak aksi! Coba lagi nanti.', 'err');
      return false;
    }
    if (!actionCounterRef.current.reset) {
      actionCounterRef.current.reset = setTimeout(() => {
        actionCounterRef.current = { count: 0, reset: null };
      }, 60000);
    }
    lastActionRef.current = now;
    setActionCount(c => c + 1);
    return true;
  };

  const addSecurityEvent = (type: string, detail: string) => {
    const ev: SecurityEvent = { id: Math.random().toString(36).slice(2), type, detail, ts: Date.now() };
    setSecurityEvents(p => [ev, ...p.slice(0, 49)]);
  };

  // ── Toast ────────────────────────────────────────────────────────────────────
  const showToast = (msg: string, type: 'ok' | 'err' | 'warn') => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg: '', type: '' }), 3500);
  };

  // ── Data loaders ─────────────────────────────────────────────────────────────
  const loadStats = useCallback(async () => {
    const r = await api('/api/admin/stats');
    const d = await r.json();
    if (d.stats) setStats(d.stats);
  }, []);

  const loadUsers = useCallback(async (page = 1) => {
    setLoading(true);
    const p = new URLSearchParams({ page: String(page), limit: '15' });
    if (usersSearch) p.set('search', usersSearch);
    if (usersFilter) p.set(usersFilter === 'banned' ? 'banned' : 'role', usersFilter === 'banned' ? 'true' : usersFilter);
    const r = await api(`/api/admin/users?${p}`);
    const d = await r.json();
    setUsers(d.users || []); setUsersTotal(d.total || 0); setUsersPage(page);
    setLoading(false);
  }, [usersSearch, usersFilter]);

  const loadComments = useCallback(async (page = 1) => {
    setLoading(true);
    const r = await api(`/api/admin/comments?page=${page}&limit=15`);
    const d = await r.json();
    setComments(d.comments || []); setCommentsTotal(d.total || 0); setCommentsPage(page);
    setLoading(false);
  }, []);

  const loadLogs = useCallback(async (page = 1) => {
    setLoading(true);
    const r = await api(`/api/admin/logs?page=${page}&limit=20`);
    const d = await r.json();
    setLogs(d.logs || []); setLogsTotal(d.total || 0); setLogsPage(page);
    setLoading(false);
  }, []);

  useEffect(() => { if (isAdmin) loadStats(); }, [isAdmin, loadStats]);
  useEffect(() => {
    if (tab === 'users') loadUsers(1);
    if (tab === 'comments') loadComments(1);
    if (tab === 'logs') loadLogs(1);
  }, [tab]);

  // ── User actions (with rate limiting) ────────────────────────────────────────
  const userAction = async (userId: string, action: string, value?: string) => {
    if (!rateCheck()) return;
    addSecurityEvent('admin_action', `${action} on user ${userId}`);
    const r = await api('/api/admin/users', { method: 'PATCH', body: JSON.stringify({ userId, action, value }) });
    const d = await r.json();
    if (r.ok) { showToast(d.message, 'ok'); loadUsers(usersPage); loadStats(); }
    else { showToast(d.error || 'Gagal', 'err'); }
    setModal(null); setModalInput('');
  };

  const deleteUser = async (userId: string) => {
    if (!rateCheck()) return;
    addSecurityEvent('admin_action', `DELETE user ${userId}`);
    const r = await api('/api/admin/users', { method: 'DELETE', body: JSON.stringify({ userId }) });
    const d = await r.json();
    if (r.ok) { showToast(d.message, 'ok'); loadUsers(usersPage); loadStats(); }
    else { showToast(d.error || 'Gagal', 'err'); }
    setConfirmDelete(null);
  };

  const deleteComment = async (commentId: string) => {
    if (!rateCheck()) return;
    const r = await api('/api/admin/comments', { method: 'DELETE', body: JSON.stringify({ commentId }) });
    const d = await r.json();
    if (r.ok) { showToast(d.message, 'ok'); loadComments(commentsPage); loadStats(); }
    else { showToast(d.error || 'Gagal', 'err'); }
  };

  const sendBroadcast = async () => {
    if (!broadcastMsg.trim() || !rateCheck()) return;
    const r = await api('/api/admin/broadcast', { method: 'POST', body: JSON.stringify({ message: broadcastMsg, type: broadcastType }) });
    const d = await r.json();
    if (r.ok) { setBroadcastMsg(''); showToast('Broadcast terkirim!', 'ok'); addSecurityEvent('broadcast', broadcastMsg.slice(0, 60)); }
    else showToast(d.error || 'Gagal', 'err');
  };

  // ── Locked screen ────────────────────────────────────────────────────────────
  if (isLocked && user && isAdmin) {
    return (
      <div className="min-h-screen bg-[#0a0a12] flex items-center justify-center p-6">
        <div className="text-center max-w-sm w-full">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6"
            style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)', boxShadow: '0 0 40px rgba(14,165,233,0.3)' }}>
            <Icon name="lock" cls="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-black text-white mb-1">Sesi Terkunci</h2>
          <p className="text-white/40 text-sm mb-8">Tidak ada aktivitas selama 15 menit</p>
          {adminPin ? (
            <>
              <input type="password" value={pinInput} onChange={e => setPinInput(e.target.value)}
                placeholder="Masukkan PIN admin..." maxLength={8}
                className="w-full bg-white/5 border-2 border-white/10 rounded-2xl px-5 py-4 text-white text-center text-xl tracking-[0.5em] outline-none focus:border-sky-d mb-4 font-mono" />
              <button onClick={() => { if (pinInput === adminPin) { resetSession(); setPinInput(''); } else { addSecurityEvent('wrong_pin', `Wrong PIN attempt`); showToast('PIN salah!', 'err'); setPinInput(''); } }}
                className="w-full py-4 text-white font-black rounded-2xl text-sm"
                style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)', boxShadow: '0 6px 24px rgba(14,165,233,0.35)' }}>
                Buka Kunci
              </button>
            </>
          ) : (
            <button onClick={resetSession}
              className="w-full py-4 text-white font-black rounded-2xl text-sm"
              style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
              Klik untuk Lanjutkan
            </button>
          )}
        </div>
      </div>
    );
  }

  // ── Access denied ─────────────────────────────────────────────────────────────
  if (!user || !isAdmin) {
    return (
      <div className="min-h-screen bg-[#0a0a12] flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="w-20 h-20 rounded-3xl bg-red/10 border border-red/20 flex items-center justify-center mx-auto mb-5">
            <Icon name="ban" cls="w-10 h-10 text-red" />
          </div>
          <h2 className="text-2xl font-black text-white mb-2">Akses Ditolak</h2>
          <p className="text-white/40 mb-6">Hanya admin yang dapat mengakses halaman ini</p>
          <Link href="/" className="px-6 py-3 bg-white/5 text-white text-sm font-bold rounded-xl border border-white/10 hover:bg-white/10 transition">
            Kembali ke Home
          </Link>
        </div>
      </div>
    );
  }

  // ── Tab config ────────────────────────────────────────────────────────────────
  const tabs: { id: Tab; label: string; icon: string; badge?: number; danger?: boolean }[] = [
    { id: 'overview',     label: 'Overview',    icon: 'home' },
    { id: 'users',        label: 'Users',       icon: 'users',  badge: stats?.totalUsers },
    { id: 'comments',     label: 'Komentar',    icon: 'chat',   badge: stats?.totalComments },
    { id: 'broadcast',    label: 'Broadcast',   icon: 'bell' },
    { id: 'logs',         label: 'Audit Log',   icon: 'log' },
    { id: 'security',     label: 'Security',    icon: 'shield', badge: securityEvents.length, danger: true },
    { id: 'maintenance',  label: 'Maintenance', icon: 'tool' },
  ];

  const sessionPct = (sessionTimeLeft / SESSION_TIMEOUT) * 100;
  const sessionMins = Math.ceil(sessionTimeLeft / 60000);

  // ── Pagination helper ─────────────────────────────────────────────────────────
  const Pagination = ({ page, total, perPage, onPage }: { page: number; total: number; perPage: number; onPage: (p: number) => void }) => {
    const pages = Math.ceil(total / perPage);
    if (pages <= 1) return null;
    return (
      <div className="flex items-center justify-center gap-2 pt-2">
        <button disabled={page <= 1} onClick={() => onPage(page - 1)}
          className="px-3 py-1.5 bg-white/5 text-white/60 text-xs font-bold rounded-lg disabled:opacity-25 hover:bg-white/10 transition">← Prev</button>
        <span className="text-xs text-white/30 font-mono px-2">{page} / {pages}</span>
        <button disabled={page >= pages} onClick={() => onPage(page + 1)}
          className="px-3 py-1.5 bg-white/5 text-white/60 text-xs font-bold rounded-lg disabled:opacity-25 hover:bg-white/10 transition">Next →</button>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen text-white" style={{ background: '#0a0a12', fontFamily: 'var(--font-jakarta)' }}>

      {/* ── Session timeout bar ───────────────────────────────────────────────── */}
      {sessionPct < 30 && (
        <div className="fixed top-0 left-0 right-0 z-[100]">
          <div className="h-0.5 bg-white/5">
            <div className="h-full bg-red transition-all duration-5000" style={{ width: `${sessionPct}%` }} />
          </div>
          <div className="flex items-center justify-center gap-2 py-1 px-4 text-[10px] font-bold" style={{ background: 'rgba(239,68,68,0.15)', color: '#FCA5A5' }}>
            <Icon name="clock" cls="w-3 h-3" />
            Sesi habis dalam {sessionMins} menit
          </div>
        </div>
      )}

      {/* ── Header ───────────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-50 flex items-center gap-3 px-4 h-[58px] border-b border-white/5"
        style={{ background: 'rgba(10,10,18,0.95)', backdropFilter: 'blur(20px)' }}>
        <Link href="/" className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/10 transition border border-white/5">
          <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white/60" strokeWidth="2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </Link>

        <div className="flex items-center gap-2.5 flex-1">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
            <Icon name="shield" cls="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="text-sm font-black text-white leading-none">Admin <span style={{ background: 'linear-gradient(to right,#38BDF8,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Dashboard</span></div>
            <div className="text-[10px] text-white/30 leading-none mt-0.5">AniVerse Control Center</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold" style={{ background: 'rgba(14,165,233,0.1)', color: '#38BDF8', border: '1px solid rgba(14,165,233,0.2)' }}>
            <div className="w-1.5 h-1.5 rounded-full bg-[#38BDF8] animate-pulse" />
            {user.username}
          </div>
          <div className="px-2.5 py-1 rounded-full text-[10px] font-black" style={{ background: 'rgba(239,68,68,0.15)', color: '#F87171', border: '1px solid rgba(239,68,68,0.25)' }}>
            ADMIN
          </div>
        </div>
      </header>

      <div className="flex">
        {/* ── Sidebar ────────────────────────────────────────────────────────── */}
        <aside className="hidden lg:flex flex-col w-56 shrink-0 sticky top-[58px] h-[calc(100vh-58px)] overflow-y-auto border-r border-white/5 py-4"
          style={{ background: 'rgba(255,255,255,0.015)' }}>
          <div className="px-3 space-y-0.5">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-left ${tab === t.id ? 'text-white' : 'text-white/40 hover:text-white/70 hover:bg-white/5'}`}
                style={tab === t.id ? { background: 'linear-gradient(135deg,rgba(2,132,199,0.3),rgba(6,182,212,0.15))', color: '#38BDF8' } : {}}>
                <Icon name={t.icon} cls="w-4 h-4 shrink-0" />
                <span className="flex-1">{t.label}</span>
                {t.badge !== undefined && t.badge > 0 && (
                  <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full"
                    style={{ background: t.danger ? 'rgba(239,68,68,0.2)' : 'rgba(14,165,233,0.2)', color: t.danger ? '#F87171' : '#38BDF8' }}>
                    {t.badge > 99 ? '99+' : t.badge}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Session timer */}
          <div className="mt-auto px-3 pb-2">
            <div className="p-3 rounded-xl border border-white/5" style={{ background: 'rgba(255,255,255,0.03)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] text-white/30 font-semibold">SESSION</span>
                <span className="text-[10px] font-mono font-bold" style={{ color: sessionPct < 20 ? '#F87171' : '#38BDF8' }}>
                  {sessionMins}m
                </span>
              </div>
              <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                <div className="h-full rounded-full transition-all duration-5000"
                  style={{ width: `${sessionPct}%`, background: sessionPct < 20 ? '#EF4444' : 'linear-gradient(to right,#0284C7,#06B6D4)' }} />
              </div>
              <div className="text-[10px] text-white/20 mt-1.5">{actionCount} aksi sesi ini</div>
            </div>
          </div>
        </aside>

        {/* ── Mobile tab bar ───────────────────────────────────────────────────── */}
        <div className="lg:hidden flex overflow-x-auto gap-1 px-3 py-2 border-b border-white/5 w-full" style={{ background: 'rgba(255,255,255,0.015)' }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap shrink-0 transition-all ${tab === t.id ? 'text-white' : 'text-white/40'}`}
              style={tab === t.id ? { background: 'linear-gradient(135deg,rgba(2,132,199,0.3),rgba(6,182,212,0.15))' } : {}}>
              <Icon name={t.icon} cls="w-3.5 h-3.5" />
              {t.label}
              {t.badge !== undefined && t.badge > 0 && (
                <span className="text-[9px] font-black px-1 rounded-full" style={{ background: t.danger ? 'rgba(239,68,68,0.3)' : 'rgba(14,165,233,0.3)', color: t.danger ? '#F87171' : '#38BDF8' }}>
                  {t.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* ── Main content ─────────────────────────────────────────────────────── */}
        <main className="flex-1 p-4 lg:p-6 max-w-5xl">

          {/* ══════════════ OVERVIEW ══════════════ */}
          {tab === 'overview' && (
            <div className="space-y-5 animate-fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black text-white">Selamat datang, {user.username}</h2>
                  <p className="text-white/30 text-sm">{new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
                <button onClick={loadStats} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 text-white/50 text-xs font-semibold hover:bg-white/10 transition border border-white/5">
                  <Icon name="refresh" cls="w-3.5 h-3.5" /> Refresh
                </button>
              </div>

              {/* Stats grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <StatCard value={stats?.totalUsers ?? '—'}    label="Total Users"   icon="users"  color="#0EA5E9" sub="Registered" />
                <StatCard value={stats?.totalAdmins ?? '—'}   label="Admin"        icon="crown"  color="#F59E0B" />
                <StatCard value={stats?.totalBanned ?? '—'}   label="Banned"       icon="ban"    color="#EF4444" />
                <StatCard value={stats?.totalComments ?? '—'} label="Komentar"     icon="chat"   color="#8B5CF6" />
                <StatCard value={stats?.totalFavorites ?? '—'}label="Favorit"      icon="heart"  color="#10B981" />
                <StatCard value={stats?.totalXpLogs ?? '—'}   label="XP Claims"   icon="xp"     color="#F97316" />
              </div>

              {/* Two column grid */}
              <div className="grid sm:grid-cols-2 gap-4">
                {/* Recent Users */}
                <div className="rounded-2xl p-4 border border-white/5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-7 h-7 rounded-lg bg-sky-d/20 flex items-center justify-center"><Icon name="users" cls="w-4 h-4 text-sky-d" /></div>
                    <h3 className="text-sm font-black text-white">User Terbaru</h3>
                  </div>
                  <div className="space-y-2">
                    {stats?.recentUsers?.slice(0, 6).map(u => (
                      <div key={u.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black text-white shrink-0"
                          style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
                          {u.username.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-bold text-white/80 truncate flex items-center gap-1.5">
                            {u.username}
                            {u.role === 'admin' && <span className="text-[8px] bg-yellow/20 text-yellow px-1.5 py-0.5 rounded font-black">ADMIN</span>}
                            {u.is_banned && <span className="text-[8px] bg-red/20 text-red px-1.5 py-0.5 rounded font-black">BAN</span>}
                          </div>
                          <div className="text-[10px] text-white/30">Lv.{u.level} • {u.xp} XP</div>
                        </div>
                        <span className="text-[10px] text-white/20 shrink-0">{timeAgo(u.created_at)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Comments */}
                <div className="rounded-2xl p-4 border border-white/5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-7 h-7 rounded-lg bg-violet/20 flex items-center justify-center"><Icon name="chat" cls="w-4 h-4 text-violet" /></div>
                    <h3 className="text-sm font-black text-white">Komentar Terbaru</h3>
                  </div>
                  <div className="space-y-2">
                    {stats?.recentComments?.slice(0, 5).map(c => (
                      <div key={c.id} className="p-3 rounded-xl border border-white/5 hover:border-white/10 transition" style={{ background: 'rgba(255,255,255,0.03)' }}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[11px] font-black text-sky-d">{c.username}</span>
                          <span className="text-[10px] text-white/20">{timeAgo(c.created_at)}</span>
                        </div>
                        <p className="text-[11px] text-white/50 line-clamp-2">{c.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick actions */}
              <div className="rounded-2xl p-4 border border-white/5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-3">Quick Actions</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { label: 'Manage Users',   icon: 'users',  tab: 'users',       color: '#0EA5E9' },
                    { label: 'Moderasi',       icon: 'chat',   tab: 'comments',    color: '#8B5CF6' },
                    { label: 'Broadcast',      icon: 'bell',   tab: 'broadcast',   color: '#10B981' },
                    { label: 'Security Log',   icon: 'shield', tab: 'security',    color: '#EF4444' },
                  ].map(q => (
                    <button key={q.tab} onClick={() => setTab(q.tab as Tab)}
                      className="flex flex-col items-center gap-2 p-3.5 rounded-xl border border-white/5 hover:border-white/15 transition group"
                      style={{ background: 'rgba(255,255,255,0.03)' }}>
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center transition"
                        style={{ background: `${q.color}22`, color: q.color }}>
                        <Icon name={q.icon} cls="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-white/50 group-hover:text-white/80 transition">{q.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ══════════════ USERS ══════════════ */}
          {tab === 'users' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-black text-white">Manajemen User</h2>
                <span className="text-xs text-white/30 font-mono">{usersTotal} users</span>
              </div>

              {/* Search & filter */}
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30"><Icon name="search" cls="w-4 h-4" /></span>
                  <input type="search" value={usersSearch} onChange={e => setUsersSearch(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && loadUsers(1)}
                    placeholder="Cari username..." className="w-full pl-9 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/20 outline-none focus:border-sky-d transition" />
                </div>
                <select value={usersFilter} onChange={e => { setUsersFilter(e.target.value); setTimeout(() => loadUsers(1), 100); }}
                  className="bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-sky-d">
                  <option value="">Semua</option>
                  <option value="admin">Admin</option>
                  <option value="user">User</option>
                  <option value="banned">Banned</option>
                </select>
                <button onClick={() => loadUsers(1)} className="px-3 py-2.5 bg-sky-d/20 text-sky-d rounded-xl border border-sky-d/30 hover:bg-sky-d/30 transition">
                  <Icon name="refresh" cls="w-4 h-4" />
                </button>
              </div>

              {/* User list */}
              <div className="space-y-2">
                {loading ? Array.from({length:5}).map((_,i) => (
                  <div key={i} className="h-16 rounded-xl skeleton" />
                )) : users.map(u => (
                  <div key={u.id} className="rounded-xl border border-white/5 p-4 hover:border-white/10 transition"
                    style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black text-white shrink-0`}
                        style={{ background: u.is_banned ? 'rgba(239,68,68,0.3)' : 'linear-gradient(135deg,#0284C7,#8B5CF6)' }}>
                        {u.username.slice(0,2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-black text-white/90">{u.username}</span>
                          {u.role==='admin' && <span className="text-[9px] bg-yellow/15 text-yellow border border-yellow/20 px-2 py-0.5 rounded-full font-black">ADMIN</span>}
                          {u.is_banned && <span className="text-[9px] bg-red/15 text-red border border-red/20 px-2 py-0.5 rounded-full font-black">BANNED</span>}
                        </div>
                        <div className="text-[11px] text-white/30 mt-0.5">
                          Lv.{u.level} · {u.xp} XP · {u.title} · Join {new Date(u.created_at).toLocaleDateString('id-ID')}
                        </div>
                        {u.is_banned && u.ban_reason && (
                          <div className="text-[10px] text-red/70 mt-1">Alasan: {u.ban_reason}</div>
                        )}
                      </div>
                    </div>
                    {/* Action buttons */}
                    <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-white/5">
                      <button onClick={() => userAction(u.id, 'set_role', u.role==='admin'?'user':'admin')}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition"
                        style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.2)' }}>
                        <Icon name="crown" cls="w-3 h-3" />
                        {u.role==='admin' ? 'Set User' : 'Set Admin'}
                      </button>

                      {!u.is_banned ? (
                        <button onClick={() => { setModal({type:'ban', user:u}); setModalInput(''); }}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition"
                          style={{ background: 'rgba(239,68,68,0.1)', color: '#F87171', border: '1px solid rgba(239,68,68,0.2)' }}>
                          <Icon name="ban" cls="w-3 h-3" /> Ban
                        </button>
                      ) : (
                        <button onClick={() => userAction(u.id,'unban')}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition"
                          style={{ background: 'rgba(16,185,129,0.1)', color: '#10B981', border: '1px solid rgba(16,185,129,0.2)' }}>
                          <Icon name="check" cls="w-3 h-3" /> Unban
                        </button>
                      )}

                      <button onClick={() => { setModal({type:'xp', user:u}); setModalInput(String(u.xp)); }}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition"
                        style={{ background: 'rgba(14,165,233,0.1)', color: '#38BDF8', border: '1px solid rgba(14,165,233,0.2)' }}>
                        <Icon name="xp" cls="w-3 h-3" /> Set XP
                      </button>

                      <button onClick={() => { setModal({type:'password', user:u}); setModalInput(''); }}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition"
                        style={{ background: 'rgba(139,92,246,0.1)', color: '#A78BFA', border: '1px solid rgba(139,92,246,0.2)' }}>
                        <Icon name="key" cls="w-3 h-3" /> Reset PW
                      </button>

                      <button onClick={() => setConfirmDelete({userId: u.id, username: u.username})}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition ml-auto"
                        style={{ background: 'rgba(239,68,68,0.08)', color: '#F87171', border: '1px solid rgba(239,68,68,0.15)' }}>
                        <Icon name="trash" cls="w-3 h-3" /> Hapus
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <Pagination page={usersPage} total={usersTotal} perPage={15} onPage={loadUsers} />
            </div>
          )}

          {/* ══════════════ COMMENTS ══════════════ */}
          {tab === 'comments' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-black text-white">Moderasi Komentar</h2>
                <span className="text-xs text-white/30 font-mono">{commentsTotal} komentar</span>
              </div>
              <div className="space-y-2">
                {loading ? Array.from({length:5}).map((_,i)=>(
                  <div key={i} className="h-20 rounded-xl skeleton"/>
                )) : comments.map(c => (
                  <div key={c.id} className="rounded-xl border border-white/5 p-4 hover:border-white/10 transition"
                    style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                          <span className="text-xs font-black text-sky-d">{c.username}</span>
                          <span className="text-[10px] text-white/20 font-mono">ep: {c.episode_id?.slice(0,12)}...</span>
                          <span className="text-[10px] text-white/20">{timeAgo(c.created_at)}</span>
                        </div>
                        <p className="text-sm text-white/60 leading-relaxed">{c.content}</p>
                      </div>
                      <button onClick={() => deleteComment(c.id)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold shrink-0 transition"
                        style={{ background: 'rgba(239,68,68,0.1)', color: '#F87171', border: '1px solid rgba(239,68,68,0.2)' }}>
                        <Icon name="trash" cls="w-3 h-3" /> Hapus
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <Pagination page={commentsPage} total={commentsTotal} perPage={15} onPage={loadComments} />
            </div>
          )}

          {/* ══════════════ BROADCAST ══════════════ */}
          {tab === 'broadcast' && (
            <div className="space-y-4 animate-fade-in">
              <h2 className="text-lg font-black text-white">Broadcast Notifikasi</h2>

              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-4 flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-green-500/20 flex items-center justify-center"><Icon name="send" cls="w-3.5 h-3.5 text-green-400" /></div>
                  Kirim ke Semua User
                </h3>

                {/* Type selector */}
                <div className="flex gap-2 mb-4">
                  {(['info','warning','success'] as const).map(t => (
                    <button key={t} onClick={() => setBroadcastType(t)}
                      className={`px-4 py-1.5 rounded-lg text-xs font-bold transition border ${broadcastType===t ? 'border-current' : 'border-white/5 text-white/30'}`}
                      style={broadcastType===t ? {
                        background: t==='info'?'rgba(14,165,233,0.2)':t==='warning'?'rgba(245,158,11,0.2)':'rgba(16,185,129,0.2)',
                        color: t==='info'?'#38BDF8':t==='warning'?'#FBBF24':'#34D399',
                      } : {}}>
                      {t === 'info' ? 'Info' : t === 'warning' ? 'Warning' : 'Success'}
                    </button>
                  ))}
                </div>

                <textarea value={broadcastMsg} onChange={e => setBroadcastMsg(e.target.value)}
                  placeholder="Tulis pesan notifikasi untuk semua user..." maxLength={500}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none resize-none h-28 focus:border-sky-d transition mb-3" />

                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-white/20 font-mono">{broadcastMsg.length}/500</span>
                  <button onClick={sendBroadcast} disabled={!broadcastMsg.trim()}
                    className="flex items-center gap-2 px-5 py-2.5 text-white text-sm font-black rounded-xl disabled:opacity-30 transition"
                    style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)', boxShadow: '0 4px 14px rgba(14,165,233,0.3)' }}>
                    <Icon name="send" cls="w-4 h-4" /> Kirim Broadcast
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-3 flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-sky-d/20 flex items-center justify-center"><Icon name="alert" cls="w-3.5 h-3.5 text-sky-d" /></div>
                  Panduan Penggunaan
                </h3>
                <ul className="space-y-2 text-xs text-white/40">
                  {[
                    'Broadcast akan dikirim ke SEMUA user aktif (non-banned)',
                    'User akan melihat notifikasi di navbar mereka',
                    'Gunakan tipe Warning untuk pengumuman penting / maintenance',
                    'Gunakan tipe Success untuk event reward atau update fitur baru',
                    'Broadcast tercatat di audit log untuk accountability',
                  ].map((t,i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-white/5 text-white/30 text-[10px] flex items-center justify-center shrink-0 mt-0.5">{i+1}</span>
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* ══════════════ AUDIT LOG ══════════════ */}
          {tab === 'logs' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-black text-white">Audit Log</h2>
                <span className="text-xs text-white/30 font-mono">{logsTotal} entri</span>
              </div>
              <div className="space-y-2">
                {loading ? Array.from({length:5}).map((_,i) => <div key={i} className="h-14 skeleton rounded-xl"/>)
                : logs.length === 0 ? (
                  <div className="text-center py-12 text-white/20">
                    <Icon name="log" cls="w-12 h-12 mx-auto mb-3" />
                    <p className="text-sm">Belum ada log</p>
                  </div>
                ) : logs.map(l => (
                  <div key={l.id} className="rounded-xl border border-white/5 px-4 py-3 flex items-center gap-3 hover:border-white/10 transition"
                    style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="w-8 h-8 rounded-lg bg-sky-d/15 flex items-center justify-center shrink-0">
                      <Icon name="log" cls="w-4 h-4 text-sky-d" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] font-black px-2 py-0.5 rounded-full" style={{ background: 'rgba(14,165,233,0.15)', color: '#38BDF8' }}>{l.admin_username}</span>
                        <span className="text-xs font-bold text-white/70">{l.action}</span>
                        {l.target_type && <span className="text-[10px] text-white/30">→ {l.target_type}</span>}
                      </div>
                      <div className="text-[10px] text-white/20 mt-0.5 font-mono">
                        {new Date(l.created_at).toLocaleString('id-ID')}
                        {l.target_id && ` · ID: ${l.target_id.slice(0,8)}...`}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Pagination page={logsPage} total={logsTotal} perPage={20} onPage={loadLogs} />
            </div>
          )}

          {/* ══════════════ SECURITY ══════════════ */}
          {tab === 'security' && (
            <div className="space-y-5 animate-fade-in">
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Icon name="shield" cls="w-5 h-5 text-red" />
                Security Center
              </h2>

              {/* Security overview cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="rounded-2xl p-4 border" style={{ background: 'rgba(16,185,129,0.05)', borderColor: 'rgba(16,185,129,0.2)' }}>
                  <div className="text-[10px] text-green-400/60 font-bold uppercase tracking-wider mb-1">Token</div>
                  <div className="text-sm font-black text-green-400">Aktif</div>
                  <div className="text-[10px] text-green-400/40 mt-1">JWT Bearer valid</div>
                </div>
                <div className="rounded-2xl p-4 border" style={{ background: 'rgba(14,165,233,0.05)', borderColor: 'rgba(14,165,233,0.2)' }}>
                  <div className="text-[10px] text-sky-d/60 font-bold uppercase tracking-wider mb-1">Actions</div>
                  <div className="text-sm font-black text-sky-d">{actionCount}</div>
                  <div className="text-[10px] text-sky-d/40 mt-1">Sesi ini</div>
                </div>
                <div className="rounded-2xl p-4 border col-span-2 sm:col-span-1" style={{ background: 'rgba(239,68,68,0.05)', borderColor: 'rgba(239,68,68,0.2)' }}>
                  <div className="text-[10px] text-red/60 font-bold uppercase tracking-wider mb-1">Events</div>
                  <div className="text-sm font-black text-red">{securityEvents.length}</div>
                  <div className="text-[10px] text-red/40 mt-1">Security log</div>
                </div>
              </div>

              {/* Admin PIN */}
              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-1 flex items-center gap-2">
                  <Icon name="lock" cls="w-4 h-4 text-sky-d" /> Admin PIN (Lock Screen)
                </h3>
                <p className="text-xs text-white/30 mb-4">PIN digunakan saat sesi admin terkunci karena idle</p>
                <div className="flex gap-2">
                  <input type="password" value={pinSetInput} onChange={e => setPinSetInput(e.target.value)}
                    placeholder={adminPin ? '••••••••' : 'Set PIN baru (4–8 digit)'}
                    maxLength={8}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-sky-d transition font-mono tracking-widest" />
                  <button onClick={() => {
                    if (pinSetInput.length >= 4) {
                      localStorage.setItem('av_admin_pin', pinSetInput);
                      setPinSetInput('');
                      showToast('PIN berhasil disimpan!', 'ok');
                      addSecurityEvent('pin_set', 'Admin PIN updated');
                    } else showToast('PIN minimal 4 digit', 'err');
                  }} className="px-4 py-2.5 text-white text-sm font-bold rounded-xl transition"
                    style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>
                    Simpan PIN
                  </button>
                  {adminPin && (
                    <button onClick={() => { localStorage.removeItem('av_admin_pin'); showToast('PIN dihapus', 'ok'); addSecurityEvent('pin_removed','Admin PIN removed'); }}
                      className="px-4 py-2.5 text-red text-sm font-bold rounded-xl border border-red/20 hover:bg-red/10 transition">
                      Hapus
                    </button>
                  )}
                </div>
              </div>

              {/* Security config info */}
              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-3 flex items-center gap-2">
                  <Icon name="shield" cls="w-4 h-4 text-green-400" /> Konfigurasi Keamanan Aktif
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {[
                    { label: 'Session Timeout',    value: '15 menit idle',          ok: true },
                    { label: 'Rate Limiting',       value: `Max ${MAX_ACTIONS_PER_MIN} aksi/menit`, ok: true },
                    { label: 'Action Cooldown',     value: `${ACTION_COOLDOWN}ms antar aksi`,       ok: true },
                    { label: 'Typed Confirmation',  value: 'Delete user wajib konfirmasi teks',      ok: true },
                    { label: 'Nonce Header',        value: 'X-Admin-Nonce tiap request',            ok: true },
                    { label: 'JWT Bearer Auth',     value: 'Token terenkripsi',                     ok: true },
                    { label: 'Audit Logging',       value: 'Semua aksi tercatat',                   ok: true },
                    { label: 'Screen Lock PIN',     value: adminPin ? 'PIN aktif' : 'Belum diset',  ok: !!adminPin },
                  ].map((c, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-white/5" style={{ background: 'rgba(255,255,255,0.02)' }}>
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${c.ok ? 'bg-green-500/20' : 'bg-yellow/20'}`}>
                        <Icon name={c.ok ? 'check' : 'alert'} cls={`w-3 h-3 ${c.ok ? 'text-green-400' : 'text-yellow'}`} />
                      </div>
                      <div>
                        <div className="text-[11px] font-bold text-white/70">{c.label}</div>
                        <div className="text-[10px] text-white/30">{c.value}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Security event log */}
              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Icon name="eye" cls="w-4 h-4 text-red" /> Live Security Events
                  </h3>
                  <button onClick={() => setSecurityEvents([])} className="text-[10px] text-white/20 hover:text-white/50 transition">Clear</button>
                </div>
                {securityEvents.length === 0 ? (
                  <p className="text-xs text-white/20 text-center py-4">Tidak ada security event</p>
                ) : (
                  <div className="space-y-1.5 max-h-60 overflow-y-auto">
                    {securityEvents.map(e => (
                      <div key={e.id} className="flex items-center gap-3 px-3 py-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${e.type.includes('rate')||e.type.includes('flood')||e.type.includes('wrong') ? 'bg-red/20 text-red' : 'bg-sky-d/20 text-sky-d'}`}>{e.type}</span>
                        <span className="text-[11px] text-white/40 flex-1 truncate">{e.detail}</span>
                        <span className="text-[9px] text-white/15 font-mono shrink-0">{new Date(e.ts).toLocaleTimeString('id-ID')}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ══════════════ MAINTENANCE ══════════════ */}
          {tab === 'maintenance' && (
            <div className="space-y-5 animate-fade-in">
              <h2 className="text-lg font-black text-white">System Maintenance</h2>

              {/* Source download */}
              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-1 flex items-center gap-2">
                  <Icon name="down" cls="w-4 h-4 text-sky-d" /> Download Source Code
                </h3>
                <p className="text-xs text-white/30 mb-4">Unduh source code proyek untuk backup atau deployment</p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <a href="/api/admin/download-source?env=false"
                    className="flex items-center gap-3 p-4 rounded-xl border border-white/5 hover:border-white/15 transition group"
                    style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="w-10 h-10 rounded-xl bg-sky-d/15 flex items-center justify-center">
                      <Icon name="down" cls="w-5 h-5 text-sky-d" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white/80">Source Code</div>
                      <div className="text-[10px] text-white/30">Tanpa file .env</div>
                    </div>
                  </a>
                  <a href="/api/admin/download-source?env=true"
                    className="flex items-center gap-3 p-4 rounded-xl border border-sky-d/20 hover:border-sky-d/40 transition group"
                    style={{ background: 'rgba(14,165,233,0.05)' }}>
                    <div className="w-10 h-10 rounded-xl bg-sky-d/20 flex items-center justify-center">
                      <Icon name="lock" cls="w-5 h-5 text-sky-d" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-sky-d">Source + .env</div>
                      <div className="text-[10px] text-sky-d/40">Termasuk konfigurasi</div>
                    </div>
                  </a>
                </div>
              </div>

              {/* Maintenance mode toggle */}
              <div className="rounded-2xl border p-5 transition" style={{ background: 'rgba(255,255,255,0.03)', borderColor: maintenanceMode ? 'rgba(245,158,11,0.3)' : 'rgba(255,255,255,0.05)' }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: maintenanceMode ? 'rgba(245,158,11,0.2)' : 'rgba(255,255,255,0.05)' }}>
                      <Icon name="tool" cls={`w-5 h-5 ${maintenanceMode ? 'text-yellow' : 'text-white/40'}`} />
                    </div>
                    <div>
                      <div className="text-sm font-black text-white">Maintenance Mode</div>
                      <div className="text-[11px] text-white/30">Tampilkan halaman maintenance ke user</div>
                    </div>
                  </div>
                  <button onClick={() => { setMaintenanceMode(m => !m); addSecurityEvent('maintenance', `Mode ${!maintenanceMode ? 'ON' : 'OFF'}`); }}
                    className={`w-12 h-6 rounded-full transition-all relative ${maintenanceMode ? '' : 'bg-white/10'}`}
                    style={{ background: maintenanceMode ? 'linear-gradient(to right,#0284C7,#06B6D4)' : undefined }}>
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${maintenanceMode ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
                {maintenanceMode && (
                  <div className="mt-4 p-3 rounded-xl flex items-center gap-2 text-xs" style={{ background: 'rgba(245,158,11,0.1)', color: '#FBBF24' }}>
                    <Icon name="alert" cls="w-4 h-4 shrink-0" />
                    Maintenance mode aktif — implementasikan penanganan di middleware server
                  </div>
                )}
              </div>

              {/* System info */}
              <div className="rounded-2xl border border-white/5 p-5" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <h3 className="text-sm font-black text-white mb-4 flex items-center gap-2">
                  <Icon name="eye" cls="w-4 h-4 text-sky-d" /> Informasi Sistem
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {[
                    { label: 'Framework',    value: 'Next.js 15 (App Router)' },
                    { label: 'Database',     value: 'Supabase (PostgreSQL)' },
                    { label: 'Auth',         value: 'JWT + bcrypt' },
                    { label: 'Deploy',       value: 'Vercel Edge Network' },
                    { label: 'Runtime',      value: 'Node.js 20 (Edge)' },
                    { label: 'Admin User',   value: user.username },
                  ].map((s, i) => (
                    <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                      <span className="text-[11px] text-white/30">{s.label}</span>
                      <span className="text-[11px] font-bold text-white/70 font-mono">{s.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ══ Modals ══════════════════════════════════════════════════════════════ */}

      {/* Generic action modal */}
      {modal && modal.type !== 'delete' && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4" onClick={() => setModal(null)}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative rounded-2xl p-6 w-full max-w-sm shadow-2xl border border-white/10 animate-slide-up"
            style={{ background: '#12101a' }} onClick={e => e.stopPropagation()}>

            {modal.type === 'ban' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-red/20 flex items-center justify-center"><Icon name="ban" cls="w-5 h-5 text-red" /></div>
                  <div>
                    <h3 className="font-black text-white">Ban User</h3>
                    <p className="text-[11px] text-white/30">{modal.user?.username}</p>
                  </div>
                </div>
                <input type="text" value={modalInput} onChange={e => setModalInput(e.target.value)}
                  placeholder="Alasan ban (opsional)" maxLength={200}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-red mb-4" />
                <div className="flex gap-2">
                  <button onClick={() => setModal(null)} className="flex-1 py-2.5 bg-white/5 text-white/50 text-sm font-bold rounded-xl hover:bg-white/10">Batal</button>
                  <button onClick={() => userAction(modal.user!.id, 'ban', modalInput)} className="flex-1 py-2.5 bg-red text-white text-sm font-black rounded-xl">Konfirmasi Ban</button>
                </div>
              </>
            )}

            {modal.type === 'xp' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-sky-d/20 flex items-center justify-center"><Icon name="xp" cls="w-5 h-5 text-sky-d" /></div>
                  <div>
                    <h3 className="font-black text-white">Set XP</h3>
                    <p className="text-[11px] text-white/30">{modal.user?.username} · saat ini {modal.user?.xp} XP</p>
                  </div>
                </div>
                <input type="number" value={modalInput} onChange={e => setModalInput(e.target.value)}
                  placeholder="Jumlah XP baru" min="0" max="999999"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-sky-d mb-4" />
                <div className="flex gap-2">
                  <button onClick={() => setModal(null)} className="flex-1 py-2.5 bg-white/5 text-white/50 text-sm font-bold rounded-xl hover:bg-white/10">Batal</button>
                  <button onClick={() => userAction(modal.user!.id, 'set_xp', modalInput)} className="flex-1 py-2.5 text-white text-sm font-black rounded-xl" style={{ background: 'linear-gradient(135deg,#0284C7,#06B6D4)' }}>Simpan</button>
                </div>
              </>
            )}

            {modal.type === 'password' && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-violet/20 flex items-center justify-center"><Icon name="key" cls="w-5 h-5 text-violet" /></div>
                  <div>
                    <h3 className="font-black text-white">Reset Password</h3>
                    <p className="text-[11px] text-white/30">{modal.user?.username}</p>
                  </div>
                </div>
                <input type="text" value={modalInput} onChange={e => setModalInput(e.target.value)}
                  placeholder="Password baru (min 6 karakter)"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-violet mb-4" />
                <div className="flex gap-2">
                  <button onClick={() => setModal(null)} className="flex-1 py-2.5 bg-white/5 text-white/50 text-sm font-bold rounded-xl hover:bg-white/10">Batal</button>
                  <button onClick={() => { if(modalInput.length < 6){showToast('Min 6 karakter',  'err'); return;} userAction(modal.user!.id, 'reset_password', modalInput); }}
                    className="flex-1 py-2.5 text-white text-sm font-black rounded-xl" style={{ background: '#7C3AED' }}>Reset</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Typed-confirmation delete modal */}
      {confirmDelete && (
        <ConfirmModal
          target={confirmDelete.username}
          action={`menghapus user "${confirmDelete.username}" secara permanen`}
          onConfirm={() => deleteUser(confirmDelete.userId)}
          onClose={() => setConfirmDelete(null)}
        />
      )}

      {/* Toast */}
      {toast.msg && (
        <div className={`fixed bottom-6 right-6 flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-bold shadow-2xl z-[999] animate-slide-up border`}
          style={{
            background: toast.type==='ok' ? 'rgba(16,185,129,0.15)' : toast.type==='warn' ? 'rgba(245,158,11,0.15)' : 'rgba(239,68,68,0.15)',
            color: toast.type==='ok' ? '#34D399' : toast.type==='warn' ? '#FBBF24' : '#F87171',
            borderColor: toast.type==='ok' ? 'rgba(16,185,129,0.3)' : toast.type==='warn' ? 'rgba(245,158,11,0.3)' : 'rgba(239,68,68,0.3)',
          }}>
          <Icon name={toast.type==='ok'?'check':toast.type==='warn'?'alert':'ban'} cls="w-4 h-4 shrink-0" />
          {toast.msg}
        </div>
      )}
    </div>
  );
}
