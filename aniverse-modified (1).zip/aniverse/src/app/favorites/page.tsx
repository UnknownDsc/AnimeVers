'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import type { Favorite } from '@/types';

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    fetch('/api/favorite', { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(d => setFavorites(d.favorites || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const removeFav = async (animeId: string) => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    await fetch('/api/favorite', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ animeId }),
    });
    setFavorites(prev => prev.filter(f => f.anime_id !== animeId));
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      <Navbar />
      <main className="max-w-2xl mx-auto px-4 pt-4">
        <h1 className="text-xl font-extrabold mb-4">Favorit <span className="gradient-text">Kamu</span></h1>

        {loading ? (
          <div className="grid grid-cols-3 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i}>
                <div className="aspect-[3/4] skeleton rounded-xl" />
                <div className="h-3 skeleton mt-2 w-3/4" />
              </div>
            ))}
          </div>
        ) : favorites.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[300px] gap-4 text-center">
            <div className="w-[74px] h-[74px] bg-bg-secondary rounded-[22px] flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-9 h-9 stroke-sky-d fill-none" strokeWidth="1.5" strokeLinecap="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
              </svg>
            </div>
            <h2 className="text-lg font-extrabold">Belum Ada Favorit</h2>
            <p className="text-sm text-text-muted max-w-[220px]">Tandai anime sebagai favorit untuk menyimpannya di sini</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {favorites.map((fav, i) => (
              <div key={fav.id} className="relative animate-fade-in" style={{ animationDelay: `${i * 0.05}s` }}>
                <Link href={`/anime/${fav.anime_id}`}>
                  <div className="aspect-[3/4] rounded-xl overflow-hidden relative bg-bg-tertiary card-hover">
                    {fav.anime_poster && <Image src={fav.anime_poster} alt={fav.anime_title || ''} fill className="object-cover" sizes="(max-width: 768px) 33vw, 200px" />}
                    <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute bottom-1.5 left-1.5 right-1.5 text-[10px] font-bold text-white line-clamp-2">{fav.anime_title}</div>
                  </div>
                </Link>
                <button
                  onClick={() => removeFav(fav.anime_id)}
                  className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center z-10 btn-press"
                >
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-red stroke-red" strokeWidth="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                  </svg>
                </button>
                <div className="text-xs font-bold truncate mt-1.5">{fav.anime_title}</div>
              </div>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
