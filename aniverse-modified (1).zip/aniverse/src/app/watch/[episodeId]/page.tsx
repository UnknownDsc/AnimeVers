'use client';

import { useState, useEffect, use } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import VideoPlayer from '@/components/VideoPlayer';
import CommentSection from '@/components/CommentSection';
import { useAuth } from '@/components/AuthProvider';
import type { EpisodeDetail } from '@/types';

export default function WatchPage({ params }: { params: Promise<{ episodeId: string }> }) {
  const { episodeId } = use(params);
  const searchParams = useSearchParams();
  const { user, refreshUser } = useAuth();
  const [episode, setEpisode] = useState<EpisodeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeServer, setActiveServer] = useState('');

  const animeId = searchParams.get('anime') || '';
  const animePoster = searchParams.get('poster') || '';
  const animeTitle = searchParams.get('title') || '';

  useEffect(() => {
    fetch(`/api/episode/${episodeId}`)
      .then(r => r.json())
      .then(d => {
        const ep = d?.data;
        setEpisode(ep);
        setActiveServer(ep?.defaultStreamingUrl || '');
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [episodeId]);

  const updateHistory = async (prog: number) => {
    if (!episode || !user) return;
    const token = localStorage.getItem('av_token');
    if (!token) return;
    fetch('/api/history', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ animeId: episode.animeId || animeId, animeTitle, animePoster, episodeId, episodeNumber: 1, progress: prog }),
    }).catch(() => {});
  };

  useEffect(() => { if (episode && user) updateHistory(0); }, [episode, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-bg-primary px-4 pt-4">
        <div className="max-w-2xl mx-auto">
          <div className="aspect-video skeleton mb-4" style={{ borderRadius: '12px' }} />
          <div className="h-6 skeleton w-3/4 mb-3 rounded-lg" />
          <div className="h-4 skeleton w-1/2 rounded-lg" />
        </div>
      </div>
    );
  }

  if (!episode) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-bg-secondary border border-border-light flex items-center justify-center mx-auto mb-4">
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-text-muted" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
          </div>
          <h2 className="text-xl font-bold mb-2">Episode tidak ditemukan</h2>
          <Link href="/" className="text-sky-d font-bold">Kembali ke Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary pb-8">
      <div className="max-w-2xl mx-auto">
        {/* Top bar */}
        <div className="flex items-center gap-3 px-4 py-3">
          <Link href={animeId ? `/anime/${animeId}` : '/'} className="w-9 h-9 flex items-center justify-center shrink-0 btn-press"
            style={{ borderRadius: '10px', background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-text-primary" strokeWidth="2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-bold truncate">{episode.title}</h1>
            <p className="text-[11px] text-text-muted">{episode.releaseTime}</p>
          </div>
        </div>

        {/* Video Player */}
        <div className="px-4">
          <VideoPlayer streamingUrl={activeServer} episodeId={episodeId} onXpEarned={refreshUser} onProgress={updateHistory} />
        </div>

        {/* Episode navigation */}
        <div className="flex gap-2.5 px-4 mt-4">
          {episode.hasPrevEpisode && episode.prevEpisode && (
            <Link href={`/watch/${episode.prevEpisode.episodeId}?anime=${episode.animeId || animeId}&poster=${encodeURIComponent(animePoster)}&title=${encodeURIComponent(animeTitle)}`}
              className="flex-1 py-2.5 bg-bg-secondary border border-border-light text-sm font-bold text-center btn-press hover:border-sky-d transition-colors flex items-center justify-center gap-1.5"
              style={{ borderRadius: '10px' }}>
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
              Prev
            </Link>
          )}
          {episode.hasNextEpisode && episode.nextEpisode && (
            <Link href={`/watch/${episode.nextEpisode.episodeId}?anime=${episode.animeId || animeId}&poster=${encodeURIComponent(animePoster)}&title=${encodeURIComponent(animeTitle)}`}
              className="flex-1 py-2.5 text-white text-sm font-bold text-center btn-press flex items-center justify-center gap-1.5"
              style={{ borderRadius: '10px', background: 'linear-gradient(135deg,#0284C7,#06B6D4)', boxShadow: '0 4px 14px rgba(14,165,233,.3)' }}>
              Next
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
            </Link>
          )}
        </div>

        {/* Episode list */}
        {episode.info?.episodeList && episode.info.episodeList.length > 0 && (
          <div className="px-4 mt-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-4 rounded-full" style={{ background: 'linear-gradient(#0284C7,#06B6D4)' }} />
              <h3 className="text-sm font-black">Semua Episode</h3>
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {episode.info.episodeList.map(ep => (
                <Link key={ep.episodeId}
                  href={`/watch/${ep.episodeId}?anime=${episode.animeId || animeId}&poster=${encodeURIComponent(animePoster)}&title=${encodeURIComponent(animeTitle)}`}
                  className={`py-2 text-center text-xs font-bold transition-all btn-press ${ep.episodeId === episodeId ? 'text-white' : 'bg-bg-secondary text-text-secondary hover:bg-bg-tertiary'}`}
                  style={{
                    borderRadius: '8px',
                    ...(ep.episodeId === episodeId ? { background: 'linear-gradient(135deg,#0284C7,#06B6D4)', boxShadow: '0 3px 10px rgba(14,165,233,.35)' } : { border: '1px solid rgba(255,255,255,0.07)' })
                  }}>
                  Ep {ep.eps}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Comments */}
        <div className="px-4">
          <CommentSection episodeId={episodeId} />
        </div>
      </div>
    </div>
  );
}
