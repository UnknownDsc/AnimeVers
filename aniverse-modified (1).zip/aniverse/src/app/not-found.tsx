import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0F172A] flex flex-col items-center justify-center px-6 text-center">
      {/* Animated Icon Container */}
      <div className="relative mb-8">
        <div className="w-32 h-32 bg-sky-d/20 rounded-[40px] flex items-center justify-center animate-pulse">
          <svg viewBox="0 0 24 24" className="w-14 h-14 fill-none stroke-sky-d" strokeWidth="1.2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M16 16s-1.5-2-4-2-4 2-4 2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
        </div>
        <div className="absolute -top-2 -right-2 bg-red text-white text-[10px] font-black px-2 py-1 rounded-lg shadow-lg">
          ERROR 404
        </div>
      </div>

      {/* Text Content */}
      <h1 className="text-4xl font-black text-white mb-3">
        Waduh, <span className="gradient-text">Kesasar!</span>
      </h1>
      <p className="text-text-muted text-sm max-w-[280px] leading-relaxed mb-10">
        Halaman yang kamu cari mungkin sudah dihapus atau pindah ke dimensi lain (Isekai).
      </p>

      {/* Actions */}
      <div className="flex flex-col gap-3 w-full max-w-[240px]">
        <Link 
          href="/" 
          className="py-3.5 bg-sky-d text-white rounded-2xl font-bold text-sm shadow-[0_10px_25px_rgba(14,165,233,0.3)] btn-press"
        >
          Balik ke Home
        </Link>
        <Link 
          href="/search" 
          className="py-3.5 bg-white/5 text-text-secondary border border-white/10 rounded-2xl font-bold text-sm btn-press"
        >
          Cari Anime Lain
        </Link>
      </div>

      {/* Decorative Background Elements */}
      <div className="fixed -bottom-20 -left-20 w-64 h-64 bg-sky-d/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="fixed -top-20 -right-20 w-64 h-64 bg-violet/10 rounded-full blur-[100px] pointer-events-none" />
    </div>
  );
}
