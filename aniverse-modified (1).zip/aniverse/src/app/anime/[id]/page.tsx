'use client';

import { useState, useEffect, use } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import { useAuth } from '@/components/AuthProvider';
import type { AnimeDetail } from '@/types';

export default function AnimeDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user } = useAuth();
  const [anime, setAnime] = useState<AnimeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFav, setIsFav] = useState(false);
  const [isSub, setIsSub] = useState(false);

  useEffect(() => {
    fetch(`/api/anime/${id}`)
      .then(r => r.json())
      .then(d => setAnime(d?.data || null))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  // Check fav/sub status
  useEffect(() => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    
    fetch('/api/favorite', { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(d => setIsFav(d.favorites?.some((f: { anime_id: string }) => f.anime_id === id) || false))
      .catch(() => {});

    fetch('/api/subscribe', { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(d => setIsSub(d.subscriptions?.some((s: { anime_id: string }) => s.anime_id === id) || false))
      .catch(() => {});
  }, [id]);

  const toggleFav = async () => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    
    if (isFav) {
      await fetch('/api/favorite', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ animeId: id }),
      });
      setIsFav(false);
    } else {
      await fetch('/api/favorite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ animeId: id, animeTitle: anime?.title, animePoster: anime?.poster }),
      });
      setIsFav(true);
    }
  };

  const toggleSub = async () => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    
    if (isSub) {
      await fetch('/api/subscribe', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ animeId: id }),
      });
      setIsSub(false);
    } else {
      await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ animeId: id, animeTitle: anime?.title }),
      });
      setIsSub(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-bg-primary">
        {user && <Navbar />}
        <div className="max-w-2xl mx-auto px-4 pt-4 space-y-4">
          <div className="h-[200px] skeleton rounded-2xl" />
          <div className="h-6 skeleton w-3/4" />
          <div className="h-4 skeleton w-1/2" />
          <div className="h-20 skeleton rounded-xl" />
        </div>
        <BottomNav />
      </div>
    );
  }

  if (!anime) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-bg-secondary border border-border-light flex items-center justify-center mx-auto mb-4"><svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-text-muted" strokeWidth="1.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
          <h2 className="text-xl font-bold mb-2">Anime tidak ditemukan</h2>
          <Link href="/" className="text-sky-d font-bold">Kembali ke Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      {user && <Navbar />}
      
      <main className="max-w-2xl mx-auto">
        {/* Hero Banner */}
        <div className="relative h-[220px] overflow-hidden">
          {anime.poster && (
            <Image src={anime.poster} alt={anime.title} fill className="object-cover opacity-30" sizes="100vw" priority />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/60 to-transparent" />
          <Link href="/" className="absolute top-4 left-4 z-10 w-9 h-9 rounded-full bg-black/40 backdrop-blur-lg flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-white" strokeWidth="2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
          </Link>
        </div>

        <div className="px-4 -mt-16 relative z-10">
          <div className="flex gap-4">
            {/* Poster */}
            <div className="w-[120px] h-[170px] rounded-xl overflow-hidden shrink-0 shadow-xl relative">
              {anime.poster && <Image src={anime.poster} alt={anime.title} fill className="object-cover" sizes="120px" />}
            </div>
            
            {/* Info */}
            <div className="flex-1 pt-16">
              <h1 className="text-xl font-extrabold leading-tight mb-1">{anime.title}</h1>
              {anime.japanese && <p className="text-xs text-text-muted mb-2">{anime.japanese}</p>}
              <div className="flex flex-wrap gap-1.5 mb-2">
                {anime.genreList?.map(g => (
                  <span key={g.genreId} className="px-2 py-0.5 bg-sky-d/15 text-sky-d text-[10px] font-bold rounded-md">{g.title}</span>
                ))}
              </div>
              <div className="flex items-center gap-3 text-xs text-text-muted">
                {anime.score && (
                  <span className="flex items-center gap-1 text-yellow font-bold">
                    <svg viewBox="0 0 24 24" className="w-3 h-3 fill-yellow"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                    {anime.score}
                  </span>
                )}
                <span>{anime.type}</span>
                <span>{anime.status}</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          {user && (
            <div className="flex gap-2.5 mt-4">
              <button
                onClick={toggleFav}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 btn-press transition-all ${
                  isFav ? 'bg-red/15 text-red border border-red/30' : 'bg-bg-secondary border border-border-light text-text-secondary'
                }`}
              >
                <svg viewBox="0 0 24 24" className={`w-4 h-4 ${isFav ? 'fill-red stroke-red' : 'fill-none stroke-current'}`} strokeWidth="2">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                {isFav ? 'Favorit' : 'Tambah Favorit'}
              </button>
              <button
                onClick={toggleSub}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 btn-press transition-all ${
                  isSub ? 'bg-sky-d/15 text-sky-d border border-sky-d/30' : 'bg-bg-secondary border border-border-light text-text-secondary'
                }`}
              >
                <svg viewBox="0 0 24 24" className={`w-4 h-4 fill-none ${isSub ? 'stroke-sky-d' : 'stroke-current'}`} strokeWidth="2" strokeLinecap="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                </svg>
                {isSub ? 'Subscribed' : 'Subscribe'}
              </button>
            </div>
          )}

          {/* Info grid */}
          <div className="grid grid-cols-2 gap-2.5 mt-4">
            {[
              { label: 'Studio', value: anime.studios || '-' },
              { label: 'Durasi', value: anime.duration || '-' },
              { label: 'Aired', value: anime.aired || '-' },
              { label: 'Episodes', value: anime.episodes?.toString() || '-' },
            ].map(item => (
              <div key={item.label} className="bg-bg-secondary rounded-xl p-3">
                <div className="text-[10px] text-text-muted">{item.label}</div>
                <div className="text-sm font-bold mt-0.5 truncate">{item.value}</div>
              </div>
            ))}
          </div>

          {/* Synopsis */}
          {anime.synopsis?.paragraphs && anime.synopsis.paragraphs.length > 0 && (
            <div className="mt-4 bg-bg-secondary rounded-2xl p-4">
              <h3 className="text-sm font-extrabold mb-2">Sinopsis</h3>
              {anime.synopsis.paragraphs.map((p, i) => (
                <p key={i} className="text-sm text-text-secondary leading-relaxed mb-2 last:mb-0">{p}</p>
              ))}
            </div>
          )}

          {/* Episode List */}
          {anime.episodeList && anime.episodeList.length > 0 && (
            <div className="mt-4">
              <h3 className="text-base font-extrabold mb-3">
                Episode <span className="gradient-text">List</span>
              </h3>
              <div className="space-y-2">
                {anime.episodeList.map(ep => (
                  <Link
                    key={ep.episodeId}
                    href={`/watch/${ep.episodeId}?anime=${id}&poster=${encodeURIComponent(anime.poster || '')}&title=${encodeURIComponent(anime.title)}`}
                    className="flex items-center gap-3 bg-bg-secondary rounded-xl p-3 hover:bg-bg-tertiary transition-colors btn-press"
                  >
                    <div className="w-10 h-10 rounded-lg bg-sky-d/15 flex items-center justify-center shrink-0">
                      <svg viewBox="0 0 24 24" className="w-4 h-4 fill-sky-d">
                        <polygon points="5 3 19 12 5 21 5 3"/>
                      </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold truncate">{ep.title}</div>
                      <div className="text-[11px] text-text-muted mt-0.5">{ep.date || `Episode ${ep.eps}`}</div>
                    </div>
                    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-text-muted shrink-0" strokeWidth="2" strokeLinecap="round">
                      <polyline points="9 18 15 12 9 6"/>
                    </svg>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Recommended */}
          {anime.recommendedAnimeList && anime.recommendedAnimeList.length > 0 && (
            <div className="mt-6">
              <h3 className="text-base font-extrabold mb-3">
                <span className="gradient-text">Rekomendasi</span>
              </h3>
              <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-1.5">
                {anime.recommendedAnimeList.map((rec, i) => (
                  <Link
                    key={rec.animeId}
                    href={`/anime/${rec.animeId}`}
                    className="shrink-0 w-[108px]"
                  >
                    <div className="w-full aspect-[3/4] rounded-xl overflow-hidden relative bg-bg-tertiary">
                      {rec.poster && <Image src={rec.poster} alt={rec.title} fill className="object-cover card-hover" sizes="108px" />}
                      <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />
                      <div className="absolute bottom-1.5 left-1.5 right-1.5 text-[10px] font-bold text-white line-clamp-2">{rec.title}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
