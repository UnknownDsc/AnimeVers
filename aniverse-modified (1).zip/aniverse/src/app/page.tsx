'use client';

import { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import BannerCarousel from '@/components/BannerCarousel';
import SearchBar from '@/components/SearchBar';
import GenreChips from '@/components/GenreChips';
import AnimeCard, { AnimeCardSkeleton } from '@/components/AnimeCard';
import { useAuth } from '@/components/AuthProvider';
import type { AnimeListItem } from '@/types';
import Link from 'next/link';
import SplashScreen from '@/components/SplashScreen';

export default function HomePage() {
  const { user, loading: authLoading } = useAuth();
  const [ongoing, setOngoing] = useState<AnimeListItem[]>([]);
  const [completed, setCompleted] = useState<AnimeListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [splash, setSplash] = useState(false);

  // Initialize splash based on session storage
  useEffect(() => {
    const hasSeenSplash = sessionStorage.getItem('av_splash_seen');
    if (!hasSeenSplash) {
      setSplash(true);
      sessionStorage.setItem('av_splash_seen', 'true');
    }
  }, []);

  useEffect(() => {
    fetch('/api/anime')
      .then(r => r.json())
      .then(d => {
        const data = d?.data || d;
        setOngoing(data?.ongoing?.animeList || []);
        setCompleted(data?.completed?.animeList || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // Loading splash screen timer
  useEffect(() => {
    if (splash) {
      const timer = setTimeout(() => setSplash(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [splash]);

  if (splash || authLoading) {
    return <SplashScreen />;
  }

  const handleGenreSelect = async (genreId: string) => {
    setLoading(true);
    try {
      if (genreId === 'all') {
        const res = await fetch('/api/anime');
        const d = await res.json();
        const data = d?.data || d;
        setOngoing(data?.ongoing?.animeList || []);
        setCompleted(data?.completed?.animeList || []);
      } else {
        const res = await fetch(`/api/anime/genre/${genreId}`);
        const d = await res.json();
        const data = d?.data;
        // In genre view, we show it in the 'Ongoing' shelf for now
        setOngoing(data?.animeList || []);
        setCompleted([]);
      }
    } catch { /* ignore */ }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-20">
      {user && <Navbar />}
      
      <main className="max-w-2xl mx-auto">
        <SearchBar />
        <GenreChips onGenreSelect={handleGenreSelect} />
        
        {/* Banner Carousel */}
        {loading ? (
          <div className="px-4 pt-4">
            <div className="w-full h-[clamp(155px,36vw,210px)] skeleton rounded-2xl" />
          </div>
        ) : (
          <BannerCarousel items={ongoing} />
        )}

        {/* New Update Section */}
        <section className="pt-5">
          <div className="flex items-center justify-between px-4 mb-3">
            <h2 className="text-base font-extrabold">
              New <span className="gradient-text">Update</span>
            </h2>
            <Link href="/search" className="text-xs font-bold text-sky-d hover:underline">Lihat Semua</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar px-4 pb-1.5">
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <AnimeCardSkeleton key={i} />)
              : ongoing.slice(0, 10).map((anime, i) => (
                  <AnimeCard key={anime.animeId} anime={anime} index={i} badge={i < 3 ? 'NEW' : undefined} />
                ))
            }
          </div>
        </section>

        {/* Popular Section */}
        <section className="pt-5">
          <div className="flex items-center justify-between px-4 mb-3">
            <h2 className="text-base font-extrabold">
              Populer <span className="gradient-text">Minggu Ini</span>
            </h2>
            <Link href="/search" className="text-xs font-bold text-sky-d hover:underline">Lihat Semua</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar px-4 pb-1.5">
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <AnimeCardSkeleton key={i} />)
              : [...ongoing].sort(() => Math.random() - 0.5).slice(0, 10).map((anime, i) => (
                  <AnimeCard key={anime.animeId} anime={anime} index={i + 4} badge={i < 2 ? 'HOT' : undefined} />
                ))
            }
          </div>
        </section>

        {/* Completed Section */}
        <section className="pt-5">
          <div className="flex items-center justify-between px-4 mb-3">
            <h2 className="text-base font-extrabold">
              <span className="gradient-text">Completed</span> Anime
            </h2>
            <Link href="/search" className="text-xs font-bold text-sky-d hover:underline">Lihat Semua</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar px-4 pb-1.5">
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <AnimeCardSkeleton key={i} />)
              : completed.slice(0, 10).map((anime, i) => (
                  <AnimeCard key={anime.animeId} anime={anime} index={i + 8} />
                ))
            }
          </div>
        </section>

        <div className="h-4" />
      </main>

      <BottomNav />
    </div>
  );
}
