'use client';

import { useState, useCallback, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import { useAuth } from '@/components/AuthProvider';
import type { AnimeListItem } from '@/types';

export default function SearchPage() {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<AnimeListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const doSearch = useCallback(async (q: string) => {
    if (q.length < 2) { setResults([]); setSearched(false); return; }
    setLoading(true);
    setSearched(true);
    try {
      const res = await fetch(`/api/anime/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setResults(data?.data?.animeList || []);
    } catch { setResults([]); }
    setLoading(false);
  }, []);

  const handleInput = (val: string) => {
    setQuery(val);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (!val.trim()) { setResults([]); setSearched(false); return; }
    timerRef.current = setTimeout(() => doSearch(val.trim()), 400);
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      {user && <Navbar />}
      <main className="max-w-2xl mx-auto">
        {/* Search input */}
        <div className="px-4 pt-4">
          <div className="flex items-center gap-2.5 bg-bg-secondary border border-border-light rounded-2xl px-4 py-3 focus-within:border-sky-d focus-within:shadow-[0_4px_20px_rgba(14,165,233,0.18)] transition-all">
            <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0 stroke-text-muted fill-none" strokeWidth="2" strokeLinecap="round">
              <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
              type="search"
              value={query}
              onChange={e => handleInput(e.target.value)}
              placeholder="Cari anime..."
              autoFocus
              className="flex-1 bg-transparent border-none outline-none text-sm text-text-primary placeholder:text-text-muted"
            />
            {loading && <div className="w-4 h-4 border-2 border-border-light border-t-sky-d rounded-full animate-spin shrink-0" />}
          </div>
        </div>

        {/* Results */}
        {!searched ? (
          <div className="flex flex-col items-center justify-center min-h-[300px] gap-4 text-center px-6">
            <div className="w-[74px] h-[74px] bg-bg-secondary rounded-[22px] flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-9 h-9 stroke-sky-d fill-none" strokeWidth="1.5" strokeLinecap="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
            </div>
            <h2 className="text-lg font-extrabold">Cari Anime</h2>
            <p className="text-sm text-text-muted max-w-[220px]">Ketik judul anime yang ingin kamu cari</p>
          </div>
        ) : loading ? (
          <div className="grid grid-cols-3 gap-3 px-4 pt-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i}>
                <div className="aspect-[3/4] skeleton rounded-xl" />
                <div className="h-3 skeleton mt-2 w-3/4" />
                <div className="h-2.5 skeleton mt-1 w-1/2" />
              </div>
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[300px] gap-3 text-center">
            <div className="text-5xl">🔍</div>
            <h2 className="text-lg font-bold">Tidak ditemukan</h2>
            <p className="text-sm text-text-muted">Coba kata kunci lain</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3 px-4 pt-4">
            {results.map((anime, i) => (
              <Link key={anime.animeId} href={`/anime/${anime.animeId}`} className="animate-fade-in" style={{ animationDelay: `${i * 0.05}s` }}>
                <div className="aspect-[3/4] rounded-xl overflow-hidden relative bg-bg-tertiary card-hover">
                  {anime.poster && <Image src={anime.poster} alt={anime.title} fill className="object-cover" sizes="(max-width: 768px) 33vw, 200px" />}
                  <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />
                  <div className="absolute bottom-1.5 left-1.5 right-1.5 text-[10px] font-bold text-white line-clamp-2">{anime.title}</div>
                </div>
                <div className="text-xs font-bold truncate mt-1.5">{anime.title}</div>
                <div className="text-[10px] text-text-muted">{anime.episodes} Eps</div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
