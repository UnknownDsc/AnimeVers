'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import type { HistoryItem } from '@/types';

export default function HistoryPage() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('av_token');
    if (!token) return;
    fetch('/api/history', { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(d => setHistory(d.history || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Baru saja';
    if (mins < 60) return `${mins}m lalu`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}j lalu`;
    const days = Math.floor(hours / 24);
    return `${days}h lalu`;
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      <Navbar />
      <main className="max-w-2xl mx-auto px-4 pt-4">
        <h1 className="text-xl font-extrabold mb-4">Riwayat <span className="gradient-text">Tontonan</span></h1>

        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-20 h-[50px] skeleton rounded-lg shrink-0" />
                <div className="flex-1">
                  <div className="h-3.5 skeleton w-3/4 mb-2" />
                  <div className="h-2.5 skeleton w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : history.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[300px] gap-4 text-center">
            <div className="w-[74px] h-[74px] bg-bg-secondary rounded-[22px] flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-9 h-9 stroke-sky-d fill-none" strokeWidth="1.5" strokeLinecap="round">
                <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
              </svg>
            </div>
            <h2 className="text-lg font-extrabold">Belum Ada Riwayat</h2>
            <p className="text-sm text-text-muted max-w-[220px]">Anime yang kamu tonton akan muncul di sini</p>
          </div>
        ) : (
          <div className="space-y-2">
            {history.map((item, i) => (
              <Link
                key={item.id}
                href={`/watch/${item.episode_id}?anime=${item.anime_id}&poster=${encodeURIComponent(item.anime_poster || '')}&title=${encodeURIComponent(item.anime_title || '')}`}
                className="flex items-center gap-3 bg-bg-secondary rounded-xl p-3 hover:bg-bg-tertiary transition-colors animate-fade-in btn-press"
                style={{ animationDelay: `${i * 0.04}s` }}
              >
                <div className="w-16 h-[48px] rounded-lg overflow-hidden shrink-0 relative bg-bg-tertiary">
                  {item.anime_poster && <Image src={item.anime_poster} alt={item.anime_title || ''} fill className="object-cover" sizes="64px" />}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold truncate">{item.anime_title || item.anime_id}</div>
                  <div className="text-[11px] text-text-muted mt-0.5">Ep {item.episode_number || '?'} • {timeAgo(item.updated_at)}</div>
                  {/* Progress bar */}
                  <div className="h-1 bg-border-light rounded-full mt-1.5 overflow-hidden">
                    <div className="h-full bg-sky-d rounded-full" style={{ width: `${item.progress}%` }} />
                  </div>
                </div>
                <span className="text-[10px] text-text-muted shrink-0">{Math.round(item.progress)}%</span>
              </Link>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
