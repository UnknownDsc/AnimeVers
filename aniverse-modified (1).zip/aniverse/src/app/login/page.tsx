'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const { login, register } = useAuth();
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState({ msg: '', type: '' });
  const [videoLeft, setVideoLeft] = useState(false);
  const [sliding, setSliding] = useState(false);

  useEffect(() => {
    const reason = sessionStorage.getItem('av_logout_reason');
    if (reason) { setError(reason); sessionStorage.removeItem('av_logout_reason'); }
  }, []);

  const showToast = (msg: string, type: 'ok' | 'err') => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg: '', type: '' }), 3200);
  };

  const checkStrength = (pw: string) => {
    let s = 0;
    if (pw.length >= 8) s++;
    if (pw.length >= 12) s++;
    if (/[A-Z]/.test(pw)) s++;
    if (/[0-9]/.test(pw)) s++;
    if (/[^A-Za-z0-9]/.test(pw)) s++;
    const levels = [
      { p: 0, c: 'transparent', t: '' },
      { p: 20, c: '#EF4444', t: 'Sangat Lemah' },
      { p: 40, c: '#F97316', t: 'Lemah' },
      { p: 60, c: '#FACC15', t: 'Cukup' },
      { p: 80, c: '#10B981', t: 'Kuat' },
      { p: 100, c: '#0EA5E9', t: 'Sangat Kuat' },
    ];
    return levels[s] || levels[0];
  };

  const triggerSlide = (toLeft: boolean) => {
    setSliding(true);
    setTimeout(() => {
      setVideoLeft(toLeft);
      setSliding(false);
    }, 450);
  };

  const switchMode = (newMode: 'login' | 'signup') => {
    if (newMode === mode) return;
    setError('');
    triggerSlide(newMode === 'signup');
    setTimeout(() => setMode(newMode), 220);
  };

  const handleSubmit = async () => {
    setError('');
    if (!username.trim()) { setError('Username wajib diisi'); return; }
    if (username.length < 3) { setError('Username minimal 3 karakter'); return; }
    if (!password) { setError('Password wajib diisi'); return; }
    if (password.length < 6) { setError('Password minimal 6 karakter'); return; }
    if (mode === 'signup' && password !== confirmPw) { setError('Password tidak cocok'); return; }

    triggerSlide(!videoLeft);
    setLoading(true);
    const result = mode === 'login' ? await login(username, password) : await register(username, password);
    if (result.success) {
      showToast(mode === 'login' ? 'Login berhasil!' : 'Akun berhasil dibuat!', 'ok');
      setTimeout(() => router.push('/'), 800);
    } else {
      setError(result.error || 'Terjadi kesalahan');
      showToast(result.error || 'Gagal', 'err');
      triggerSlide(videoLeft);
    }
    setLoading(false);
  };

  const strength = checkStrength(password);

  const VideoPanel = () => (
    <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden"
      style={{ background: 'linear-gradient(135deg,#0284C7 0%,#0EA5E9 40%,#06B6D4 70%,#38BDF8 100%)' }}>
      <div className="absolute inset-0 opacity-10"
        style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.4) 1px, transparent 1px),linear-gradient(90deg,rgba(255,255,255,.4) 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
      <div className="absolute w-[280px] h-[280px] rounded-full bg-white/10 -top-20 -right-16" style={{ animation: 'floatAni 7s ease-in-out infinite' }} />
      <div className="absolute w-[180px] h-[180px] rounded-full bg-white/8 -bottom-12 -left-10" style={{ animation: 'floatAni 5s ease-in-out infinite reverse 1.5s' }} />
      <div className="absolute w-[80px] h-[80px] rounded-full bg-white/15 top-[38%] left-[8%]" style={{ animation: 'floatAni 6s ease-in-out infinite 0.9s' }} />
      <div className="relative z-10 flex flex-col items-center px-10 text-center">
        <div className="w-[72px] h-[72px] rounded-[22px] bg-white/25 border-2 border-white/40 flex items-center justify-center mb-5 backdrop-blur-lg"
          style={{ animation: 'floatAni 5s ease-in-out infinite', boxShadow: '0 8px 32px rgba(0,0,0,.15)' }}>
          <svg viewBox="0 0 24 24" className="w-8 h-8 fill-white drop-shadow"><path d="M8 5v14l11-7z"/></svg>
        </div>
        <div className="text-[34px] font-black text-white tracking-tight drop-shadow-lg mb-1">AniVerse</div>
        <div className="text-[11px] text-white/80 tracking-[2.5px] uppercase mb-8">Streaming Tanpa Batas</div>
        <div className="flex flex-col gap-3 w-full max-w-[200px]">
          {[
            { icon: <path d="M8 5v14l11-7z"/>, fill: true, label: '2.4K+ Judul', sub: 'Anime Tersedia' },
            { icon: <><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></>, fill: false, label: 'Sub & Dub', sub: 'Multi Audio' },
            { icon: <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>, fill: false, label: 'Gratis', sub: 'Tanpa Langganan' },
          ].map((item, i) => (
            <div key={i} className="bg-white/20 border border-white/30 backdrop-blur-lg rounded-2xl px-4 py-3 flex items-center gap-3"
              style={{ animation: `floatAni ${5+i}s ease-in-out infinite ${i*0.5}s` }}>
              <div className="w-9 h-9 rounded-xl bg-white/25 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill={item.fill ? 'white' : 'none'} stroke="white" strokeWidth="2" strokeLinecap="round">{item.icon}</svg>
              </div>
              <div className="text-left">
                <div className="text-white font-black text-sm">{item.label}</div>
                <div className="text-white/70 text-[10px]">{item.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#e8f4fd] via-[#f0faff] to-[#dff6ff] relative overflow-hidden p-4">
      <div className="absolute top-[-10%] left-[-5%] w-[500px] h-[500px] rounded-full bg-[#38BDF8]/20 blur-[80px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[400px] h-[400px] rounded-full bg-[#06B6D4]/20 blur-[80px] pointer-events-none" />

      <div className="relative w-full max-w-[960px] bg-white/80 backdrop-blur-xl rounded-[28px] overflow-hidden flex min-h-[560px]"
        style={{ boxShadow: '0 30px 80px rgba(14,165,233,.18),0 8px 24px rgba(0,0,0,.06)', border: '1.5px solid rgba(14,165,233,.15)' }}>

        {/* LEFT SLOT */}
        <div className="hidden md:block w-[45%] shrink-0 overflow-hidden relative"
          style={{
            order: videoLeft ? 0 : 2,
            transform: sliding ? (videoLeft ? 'translateX(-30px)' : 'translateX(30px)') : 'translateX(0)',
            opacity: sliding ? 0.6 : 1,
            transition: 'transform 0.45s cubic-bezier(0.4,0,0.2,1), opacity 0.45s ease',
          }}>
          {videoLeft ? <VideoPanel /> : (
            <div className="w-full h-full flex items-center justify-center bg-gray-50 p-8">
              {/* Form placeholder so layout doesn't break */}
            </div>
          )}
        </div>

        {/* Video panel always visible in the non-form slot */}
        <div className="hidden md:block w-[45%] shrink-0 overflow-hidden relative"
          style={{
            order: videoLeft ? 2 : 0,
            transform: sliding ? (videoLeft ? 'translateX(30px)' : 'translateX(-30px)') : 'translateX(0)',
            opacity: sliding ? 0.6 : 1,
            transition: 'transform 0.45s cubic-bezier(0.4,0,0.2,1), opacity 0.45s ease',
          }}>
          <VideoPanel />
        </div>

        {/* Divider */}
        <div className="hidden md:block w-px shrink-0 bg-gradient-to-b from-transparent via-[#0EA5E9]/20 to-transparent" style={{ order: 1 }} />

        {/* FORM PANEL */}
        <div className="flex-1 flex flex-col justify-center px-8 sm:px-12 py-10" style={{ order: 1 }}>
          {/* Mobile brand */}
          <div className="flex items-center gap-3 mb-7 md:hidden">
            <div className="w-10 h-10 rounded-[12px] flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#0284C7,#38BDF8)' }}>
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <span className="text-xl font-black" style={{ background: 'linear-gradient(to right,#0284C7,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>AniVerse</span>
          </div>

          <div className="mb-7">
            <h1 className="text-[28px] font-black text-gray-800 tracking-tight leading-tight mb-1">
              {mode === 'login'
                ? <><span style={{ background: 'linear-gradient(to right,#0284C7,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Selamat</span> Datang</>
                : <>Buat <span style={{ background: 'linear-gradient(to right,#0284C7,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Akun</span></>}
            </h1>
            <p className="text-sm text-gray-500">
              {mode === 'login' ? 'Masuk dan lanjutkan menonton anime favoritmu' : 'Bergabung dengan komunitas AniVerse sekarang'}
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-2.5 mb-5">
              <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0 fill-none stroke-current" strokeWidth="2" strokeLinecap="round">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              {error}
            </div>
          )}

          {/* Username */}
          <div className="mb-4">
            <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase tracking-wider">Username</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#0EA5E9]">
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>
              </span>
              <input type="text" value={username} onChange={e => setUsername(e.target.value)}
                placeholder={mode === 'login' ? 'Masukkan username' : 'Pilih username unik'} maxLength={30}
                className="w-full pl-10 pr-4 py-3 bg-[#f0f9ff] border-2 border-[#bae6fd] rounded-xl text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:border-[#0EA5E9] focus:bg-white transition-all"
                style={{ focusShadow: '0 0 0 3px rgba(14,165,233,.12)' } as React.CSSProperties}
                onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>
          </div>

          {/* Password */}
          <div className="mb-4">
            <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase tracking-wider">Password</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#0EA5E9]">
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
              </span>
              <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                placeholder={mode === 'login' ? 'Masukkan password' : 'Min 6 karakter'} maxLength={64}
                className="w-full pl-10 pr-10 py-3 bg-[#f0f9ff] border-2 border-[#bae6fd] rounded-xl text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:border-[#0EA5E9] focus:bg-white transition-all"
                onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#0EA5E9] transition-colors">
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round">
                  {showPw ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><line x1="1" y1="1" x2="23" y2="23"/></>
                    : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>}
                </svg>
              </button>
            </div>
            {mode === 'signup' && password && (
              <><div className="h-[3px] rounded-full bg-gray-200 mt-2 overflow-hidden">
                <div className="h-full rounded-full transition-all duration-400" style={{ width: `${strength.p}%`, background: strength.c }} />
              </div><div className="text-[10px] text-right mt-0.5" style={{ color: strength.c }}>{strength.t}</div></>
            )}
          </div>

          {/* Confirm Password */}
          {mode === 'signup' && (
            <div className="mb-5">
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase tracking-wider">Konfirmasi Password</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#0EA5E9]">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2" strokeLinecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </span>
                <input type="password" value={confirmPw} onChange={e => setConfirmPw(e.target.value)}
                  placeholder="Ulangi password" maxLength={64}
                  className="w-full pl-10 pr-4 py-3 bg-[#f0f9ff] border-2 border-[#bae6fd] rounded-xl text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:border-[#0EA5E9] focus:bg-white transition-all"
                  onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
              </div>
            </div>
          )}

          {/* Submit */}
          <button onClick={handleSubmit} disabled={loading}
            className="w-full py-3.5 font-black text-sm text-white rounded-xl transition-all disabled:opacity-60 mb-4 flex items-center justify-center gap-2"
            style={{ background: 'linear-gradient(135deg,#0284C7,#0EA5E9,#06B6D4)', boxShadow: '0 6px 24px rgba(14,165,233,.35)' }}>
            {loading ? <div className="w-5 h-5 border-[2.5px] border-white/30 border-t-white rounded-full animate-spin" />
              : <>{mode === 'login' ? 'Masuk' : 'Daftar Sekarang'}
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg></>}
          </button>

          <div className="flex items-center gap-3 mb-4 text-gray-400 text-[11.5px]">
            <div className="flex-1 h-px bg-gray-200" />atau<div className="flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-center text-sm text-gray-500">
            {mode === 'login' ? 'Belum punya akun? ' : 'Sudah punya akun? '}
            <button onClick={() => switchMode(mode === 'login' ? 'signup' : 'login')}
              className="font-black text-[#0EA5E9] hover:text-[#0284C7] transition-colors hover:underline">
              {mode === 'login' ? 'Daftar Sekarang' : 'Masuk'}
            </button>
          </p>
        </div>
      </div>

      {toast.msg && (
        <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full text-sm font-bold z-[9999] shadow-xl flex items-center gap-2 animate-slide-up ${toast.type === 'ok' ? 'text-white' : 'text-white'}`}
          style={{ background: toast.type === 'ok' ? 'linear-gradient(to right,#10B981,#06B6D4)' : 'linear-gradient(to right,#EF4444,#F97316)' }}>
          {toast.type === 'ok'
            ? <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            : <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-white" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>}
          {toast.msg}
        </div>
      )}

      <style>{`
        @keyframes floatAni { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
      `}</style>
    </div>
  );
}
