/* eslint-disable @typescript-eslint/no-explicit-any */
// =============================================================
// AniVerse — Unified API Handler (Catch-all)
// =============================================================

import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { hashPassword, comparePassword, generateToken, getUserFromHeader } from '@/lib/auth';
import { getHome, getAnimeDetail, getEpisodeDetail, searchAnime, getGenres, getGenreAnime } from '@/lib/anime-api';
import { getLevel, getTitle, XP_PER_WATCH } from '@/lib/constants';
import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

type RouteParams = { params: Promise<{ route: string[] }> };

// -------------------------------------------------------
// Helpers
// -------------------------------------------------------
async function requireAuth(request: Request) {
  const user = await getUserFromHeader(request);
  if (!user || !user.id) return null;
  
  // Live ban check
  try {
    const { data, error } = await supabase.from('users').select('is_banned').eq('id', user.id).single();
    if (error || !data) {
      if (error?.code !== 'PGRST116') { // PGRST116 is 'no rows'
        console.error('[Ban Check Error]', error);
      }
      return user; // Jika error query, izinkan (fallback aman)
    }
    if (data.is_banned) return null; 
    return user;
  } catch (err) {
    console.error('[requireAuth Exception]', err);
    return user;
  }
}

async function requireAdmin(request: Request) {
  const user = await getUserFromHeader(request);
  if (!user || user.role !== 'admin') return null;
  // Admin ban check (just in case)
  const { data } = await supabase.from('users').select('is_banned').eq('id', user.id).single();
  if (data?.is_banned) return null;
  return user;
}

const json = NextResponse.json;
const ERR = (msg: string, s: number) => json({ error: msg }, { status: s });

// -------------------------------------------------------
// GET dispatcher
// -------------------------------------------------------
export async function GET(request: Request, { params }: RouteParams) {
  const { route } = await params;
  const path = route.join('/');
  const sp = new URL(request.url).searchParams;

  try {
    switch (path) {
      case 'me': return handleMe(request);
      case 'anime': return json(await getHome());
      case 'anime/search': {
        const q = sp.get('q');
        if (!q || q.trim().length < 2) return ERR('Query minimal 2 karakter', 400);
        return json(await searchAnime(q.trim()));
      }
      case 'anime/genre': return json(await getGenres());
      case 'comment': return handleCommentGet(request);
      case 'favorite': return handleFavoriteGet(request);
      case 'history': return handleHistoryGet(request);
      case 'subscribe': return handleSubscribeGet(request);
      case 'notifications': return handleNotificationsGet(request);
      
      // Admin
      case 'admin/stats': return handleAdminStats(request);
      case 'admin/users': return handleAdminUsersGet(request);
       case 'admin/comments': return handleAdminCommentsGet(request);
      case 'admin/logs': return handleAdminLogs(request);
      case 'admin/download-source': return handleDownloadSource(request);

      default:
        // Dynamic routes: anime/:id or episode/:id
        if (path.startsWith('anime/genre/')) {
          const id = route[2];
          const page = parseInt(sp.get('page') || '1');
          return json(await getGenreAnime(id, page));
        }
        if (path.startsWith('anime/')) {
          const id = route[1];
          return json(await getAnimeDetail(id));
        }
        if (path.startsWith('episode/')) {
          const id = route[1];
          return json(await getEpisodeDetail(id));
        }
        return ERR(`Unknown route: ${path}`, 404);
    }
  } catch (error) {
    console.error(`[GET /api/${path}]`, error);
    return ERR('Server error', 500);
  }
}

// -------------------------------------------------------
// POST dispatcher
// -------------------------------------------------------
export async function POST(request: Request, { params }: RouteParams) {
  const { route } = await params;
  const path = route.join('/');

  try {
    switch (path) {
      case 'register': return handleRegister(request);
      case 'login': return handleLogin(request);
      case 'logout': return handleLogout();
      case 'comment': return handleCommentPost(request);
      case 'favorite': return handleFavoritePost(request);
      case 'history': return handleHistoryPost(request);
      case 'xp': return handleXp(request);
      case 'subscribe': return handleSubscribePost(request);
      case 'admin/broadcast': return handleAdminBroadcast(request);
      default: return ERR(`Unknown route: ${path}`, 404);
    }
  } catch (error) {
    console.error(`[POST /api/${path}]`, error);
    return ERR('Server error', 500);
  }
}

// -------------------------------------------------------
// PATCH dispatcher
// -------------------------------------------------------
export async function PATCH(request: Request, { params }: RouteParams) {
  const { route } = await params;
  const path = route.join('/');

  try {
    switch (path) {
      case 'notifications': return handleNotificationsPatch(request);
      case 'admin/users': return handleAdminUsersPatch(request);
      default: return ERR(`Unknown route: ${path}`, 404);
    }
  } catch (error) {
    console.error(`[PATCH /api/${path}]`, error);
    return ERR('Server error', 500);
  }
}

// -------------------------------------------------------
// DELETE dispatcher
// -------------------------------------------------------
export async function DELETE(request: Request, { params }: RouteParams) {
  const { route } = await params;
  const path = route.join('/');

  try {
    switch (path) {
      case 'favorite': return handleFavoriteDelete(request);
      case 'subscribe': return handleSubscribeDelete(request);
      case 'admin/users': return handleAdminUsersDelete(request);
      case 'admin/comments': return handleAdminCommentsDelete(request);
      default: return ERR(`Unknown route: ${path}`, 404);
    }
  } catch (error) {
    console.error(`[DELETE /api/${path}]`, error);
    return ERR('Server error', 500);
  }
}

// =============================================================
// HANDLERS (Same logic as before)
// =============================================================

async function handleRegister(request: Request) {
  const { username, password } = await request.json();
  if (!username || !password) return ERR('Username dan password wajib diisi', 400);
  if (username.length < 3 || username.length > 30) return ERR('Username harus 3-30 karakter', 400);
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return ERR('Username hanya boleh huruf, angka, dan underscore', 400);
  if (password.length < 6) return ERR('Password minimal 6 karakter', 400);

  const { data: existing } = await supabase.from('users').select('id').ilike('username', username).single();
  if (existing) return ERR('Username sudah digunakan', 409);

  const hashedPassword = await hashPassword(password);
  const { data: user, error } = await supabase.from('users').insert({
    username, password: hashedPassword, role: 'user', xp: 0, level: 1, title: 'Newbie', is_banned: false,
  }).select('id, username, role, xp, level, title, is_banned, created_at').single();
  if (error || !user) return ERR('Gagal mendaftar. Coba lagi.', 500);

  const token = await generateToken({ id: user.id, username: user.username, role: user.role });
  const response = json({ message: 'Registrasi berhasil!', user: { id: user.id, username: user.username, role: user.role, xp: user.xp, level: user.level, title: user.title, is_banned: user.is_banned }, token });
  response.cookies.set('av_token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 60 * 60 * 24 * 7, path: '/' });
  return response;
}

async function handleLogin(request: Request) {
  const { username, password } = await request.json();
  if (!username || !password) return ERR('Username dan password wajib diisi', 400);

  const { data: user, error } = await supabase.from('users').select('*').ilike('username', username).single();
  if (error || !user) return ERR('Akun tidak ditemukan', 401);
  if (user.is_banned) return ERR(`Akun dibanned: ${user.ban_reason || 'Pelanggaran aturan'}`, 403);

  const valid = await comparePassword(password, user.password);
  if (!valid) return ERR('Password salah', 401);

  const token = await generateToken({ id: user.id, username: user.username, role: user.role });
  const response = json({ message: 'Login berhasil!', user: { id: user.id, username: user.username, role: user.role, xp: user.xp, level: user.level, title: user.title, is_banned: user.is_banned }, token });
  response.cookies.set('av_token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 60 * 60 * 24 * 7, path: '/' });
  return response;
}

function handleLogout() {
  const response = json({ message: 'Logout berhasil' });
  response.cookies.set('av_token', '', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 0, path: '/' });
  return response;
}

async function handleMe(request: Request) {
  const payload = await requireAuth(request);
  if (!payload) return ERR('Unauthorized or Banned', 401);
  const { data: user, error } = await supabase.from('users').select('id, username, role, xp, level, title, is_banned, created_at').eq('id', payload.id).single();
  if (error || !user) return ERR('User tidak ditemukan', 404);
  if (user.is_banned) return ERR('Akun dibanned', 403);
  return json({ user });
}

async function handleCommentGet(request: Request) {
  const { searchParams } = new URL(request.url);
  const episodeId = searchParams.get('episodeId');
  if (!episodeId) return ERR('episodeId required', 400);

  const { data: comments, error } = await supabase.from('comments')
    .select('id, user_id, episode_id, content, created_at')
    .eq('episode_id', episodeId)
    .eq('is_deleted', false)
    .order('created_at', { ascending: false }).limit(50);
  if (error) throw error;

  const userIds = [...new Set(comments?.map(c => c.user_id) || [])];
  let usernameMap: Record<string, string> = {};
  if (userIds.length > 0) {
    const { data: users } = await supabase.from('users').select('id, username').in('id', userIds);
    usernameMap = Object.fromEntries(users?.map(u => [u.id, u.username]) || []);
  }
  return json({ comments: comments?.map(c => ({ ...c, username: usernameMap[c.user_id] || 'Unknown' })) });
}

async function handleCommentPost(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Login dulu untuk berkomentar', 401);
  const { episodeId, content } = await request.json();
  if (!episodeId || !content?.trim()) return ERR('episodeId dan content wajib diisi', 400);
  if (content.length > 500) return ERR('Komentar maksimal 500 karakter', 400);

  const { data, error } = await supabase.from('comments').insert({ user_id: user.id, episode_id: episodeId, content: content.trim() }).select().single();
  if (error) throw error;
  return json({ comment: { ...data, username: user.username } });
}

async function handleFavoriteGet(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { data, error } = await supabase.from('favorites').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
  if (error) throw error;
  return json({ favorites: data });
}

async function handleFavoritePost(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { animeId, animeTitle, animePoster } = await request.json();
  if (!animeId) return ERR('animeId required', 400);
  const { data, error } = await supabase.from('favorites').upsert({ user_id: user.id, anime_id: animeId, anime_title: animeTitle || '', anime_poster: animePoster || '' }, { onConflict: 'user_id,anime_id' }).select().single();
  if (error) throw error;
  return json({ favorite: data, message: 'Ditambahkan ke favorit!' });
}

async function handleFavoriteDelete(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { animeId } = await request.json();
  if (!animeId) return ERR('animeId required', 400);
  const { error } = await supabase.from('favorites').delete().eq('user_id', user.id).eq('anime_id', animeId);
  if (error) throw error;
  return json({ message: 'Dihapus dari favorit' });
}

async function handleHistoryGet(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { data, error } = await supabase.from('history').select('*').eq('user_id', user.id).order('updated_at', { ascending: false }).limit(50);
  if (error) throw error;
  return json({ history: data });
}

async function handleHistoryPost(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { animeId, animeTitle, animePoster, episodeId, episodeNumber, progress } = await request.json();
  if (!animeId || !episodeId) return ERR('animeId dan episodeId required', 400);
  const { data, error } = await supabase.from('history').upsert({
    user_id: user.id, anime_id: animeId, anime_title: animeTitle || '', anime_poster: animePoster || '',
    episode_id: episodeId, episode_number: episodeNumber || 0, progress: Math.min(progress || 0, 100),
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,episode_id' }).select().single();
  if (error) throw error;
  return json({ history: data });
}

async function handleXp(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { episodeId, watchTime, progress } = await request.json();
  if (!episodeId) return ERR('episodeId required', 400);
  const isEligible = progress >= 80 || watchTime >= 300;
  if (!isEligible) return ERR('Tonton minimal 5 menit atau 80% untuk mendapat XP', 400);

  // Allow multiple claims per episode as requested
  /*
  const { data: existingLog } = await supabase.from('xp_logs').select('id').eq('user_id', user.id).eq('episode_id', episodeId).single();
  if (existingLog) return json({ error: 'XP sudah diklaim untuk episode ini', alreadyClaimed: true }, { status: 409 });
  */

  const { data: userData, error: userErr } = await supabase.from('users').select('xp, level').eq('id', user.id).single();
  if (userErr || !userData) return ERR('User not found', 404);

  const newXp = userData.xp + XP_PER_WATCH;
  const newLevel = getLevel(newXp);
  const newTitle = getTitle(newLevel);

  const { error: updateErr } = await supabase.from('users').update({ xp: newXp, level: newLevel, title: newTitle }).eq('id', user.id);
  if (updateErr) throw updateErr;

  await supabase.from('xp_logs').insert({ user_id: user.id, episode_id: episodeId, xp_gained: XP_PER_WATCH });
  return json({ message: `+${XP_PER_WATCH} XP!`, xp: newXp, level: newLevel, title: newTitle, levelUp: newLevel > userData.level });
}

async function handleSubscribeGet(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { data, error } = await supabase.from('subscriptions').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
  if (error) throw error;
  return json({ subscriptions: data });
}

async function handleSubscribePost(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { animeId, animeTitle } = await request.json();
  if (!animeId) return ERR('animeId required', 400);
  const { data, error } = await supabase.from('subscriptions').upsert({ user_id: user.id, anime_id: animeId, anime_title: animeTitle || '' }, { onConflict: 'user_id,anime_id' }).select().single();
  if (error) throw error;
  return json({ subscription: data, message: 'Berlangganan berhasil!' });
}

async function handleSubscribeDelete(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { animeId } = await request.json();
  if (!animeId) return ERR('animeId required', 400);
  const { error } = await supabase.from('subscriptions').delete().eq('user_id', user.id).eq('anime_id', animeId);
  if (error) throw error;
  return json({ message: 'Berhenti berlangganan' });
}

async function handleNotificationsGet(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { data, error } = await supabase.from('notifications').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(20);
  if (error) throw error;
  const unreadCount = data?.filter(n => !n.is_read).length || 0;
  return json({ notifications: data, unreadCount });
}

async function handleNotificationsPatch(request: Request) {
  const user = await requireAuth(request);
  if (!user) return ERR('Unauthorized', 401);
  const { notificationId } = await request.json();
  if (notificationId) {
    await supabase.from('notifications').update({ is_read: true }).eq('id', notificationId).eq('user_id', user.id);
  } else {
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);
  }
  return json({ message: 'Marked as read' });
}

async function handleAdminStats(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);

  const [
    { count: totalUsers }, { count: totalAdmins }, { count: totalBanned },
    { count: totalComments }, { count: totalFavorites }, { count: totalXpLogs },
  ] = await Promise.all([
    supabase.from('users').select('*', { count: 'exact', head: true }),
    supabase.from('users').select('*', { count: 'exact', head: true }).eq('role', 'admin'),
    supabase.from('users').select('*', { count: 'exact', head: true }).eq('is_banned', true),
    supabase.from('comments').select('*', { count: 'exact', head: true }),
    supabase.from('favorites').select('*', { count: 'exact', head: true }),
    supabase.from('xp_logs').select('*', { count: 'exact', head: true }),
  ]);

  const { data: recentUsers } = await supabase.from('users').select('id, username, role, xp, level, title, is_banned, created_at').order('created_at', { ascending: false }).limit(5);
  const { data: recentComments } = await supabase.from('comments').select('*, users!inner(username)').order('created_at', { ascending: false }).limit(5);

  const enrichedComments = recentComments?.map((c: any) => ({ ...c, username: c.users?.username || 'Unknown', users: undefined })) || [];

  return json({
    stats: {
      totalUsers: totalUsers || 0, totalAdmins: totalAdmins || 0, totalBanned: totalBanned || 0,
      totalComments: totalComments || 0, totalFavorites: totalFavorites || 0, totalXpLogs: totalXpLogs || 0,
      recentUsers: recentUsers || [], recentComments: enrichedComments,
    },
  });
}

async function handleAdminUsersGet(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);

  const sp = new URL(request.url).searchParams;
  const page = parseInt(sp.get('page') || '1');
  const limit = parseInt(sp.get('limit') || '20');
  const search = sp.get('search') || '';
  const role = sp.get('role') || '';
  const banned = sp.get('banned') || '';

  let query = supabase.from('users')
    .select('id, username, role, xp, level, title, is_banned, ban_reason, created_at', { count: 'exact' })
    .order('created_at', { ascending: false }).range((page - 1) * limit, page * limit - 1);

  if (search) query = query.ilike('username', `%${search}%`);
  if (role === 'admin' || role === 'user') query = query.eq('role', role);
  if (banned === 'true') query = query.eq('is_banned', true);
  if (banned === 'false') query = query.eq('is_banned', false);

  const { data: users, count, error } = await query;
  if (error) throw error;
  return json({ users: users || [], total: count || 0, page, totalPages: Math.ceil((count || 0) / limit) });
}

async function handleAdminUsersPatch(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);

  const { userId, action, value } = await request.json();
  if (!userId || !action) return ERR('userId and action required', 400);

  let updateData: Record<string, any> = {};
  let logAction = '';

  switch (action) {
    case 'set_role':
      if (value !== 'admin' && value !== 'user') return ERR('Role harus admin atau user', 400);
      updateData = { role: value }; logAction = `Set role to ${value}`; break;
    case 'ban':
      updateData = { is_banned: true, ban_reason: value || 'Pelanggaran aturan' }; logAction = `Banned: ${value || 'No reason'}`; break;
    case 'unban':
      updateData = { is_banned: false, ban_reason: null }; logAction = 'Unbanned'; break;
    case 'set_xp': {
      const xp = parseInt(value); if (isNaN(xp) || xp < 0) return ERR('XP harus angka positif', 400);
      const level = Math.floor(xp / 100) + 1;
      let title = 'Newbie';
      if (level >= 100) title = 'Anime Master'; else if (level >= 50) title = 'Otaku';
      else if (level >= 25) title = 'Watcher'; else if (level >= 10) title = 'Beginner';
      updateData = { xp, level, title }; logAction = `Set XP to ${xp}`; break;
    }
    case 'reset_password':
      if (!value || value.length < 6) return ERR('Password minimal 6 karakter', 400);
      updateData = { password: await hashPassword(value) }; logAction = 'Reset password'; break;
    default:
      return ERR('Action tidak dikenal', 400);
  }

  updateData.updated_at = new Date().toISOString();
  const { error } = await supabase.from('users').update(updateData).eq('id', userId);
  if (error) throw error;

  await supabase.from('admin_logs').insert({ admin_id: admin.id, action: logAction, target_type: 'user', target_id: userId, details: { action, value } });
  return json({ message: `Berhasil: ${logAction}` });
}

async function handleAdminUsersDelete(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  const { userId } = await request.json();
  if (!userId) return ERR('userId required', 400);
  if (userId === admin.id) return ERR('Tidak bisa menghapus akun sendiri', 400);

  const { error } = await supabase.from('users').delete().eq('id', userId);
  if (error) throw error;
  await supabase.from('admin_logs').insert({ admin_id: admin.id, action: 'Deleted user', target_type: 'user', target_id: userId });
  return json({ message: 'User berhasil dihapus' });
}

async function handleAdminCommentsGet(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  const sp = new URL(request.url).searchParams;
  const page = parseInt(sp.get('page') || '1');
  const limit = parseInt(sp.get('limit') || '20');

  const { data, count, error } = await supabase.from('comments').select('*, users!inner(username)', { count: 'exact' })
    .eq('is_deleted', false).order('created_at', { ascending: false }).range((page - 1) * limit, page * limit - 1);
  if (error) throw error;

  const comments = data?.map((c: any) => ({ ...c, username: c.users?.username || 'Unknown', users: undefined })) || [];
  return json({ comments, total: count || 0, page, totalPages: Math.ceil((count || 0) / limit) });
}

async function handleAdminCommentsDelete(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  const { commentId } = await request.json();
  if (!commentId) return ERR('commentId required', 400);

  const { error } = await supabase.from('comments').update({ is_deleted: true }).eq('id', commentId);
  if (error) throw error;
  await supabase.from('admin_logs').insert({ admin_id: admin.id, action: 'Deleted comment', target_type: 'comment', target_id: commentId });
  return json({ message: 'Komentar berhasil dihapus' });
}

async function handleAdminBroadcast(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  const { message, targetUsers, animeId } = await request.json();
  if (!message?.trim()) return ERR('Message wajib diisi', 400);

  let userIds: string[] = [];
  if (targetUsers && Array.isArray(targetUsers) && targetUsers.length > 0) {
    userIds = targetUsers;
  } else {
    const { data: allUsers } = await supabase.from('users').select('id').eq('is_banned', false);
    userIds = allUsers?.map(u => u.id) || [];
  }
  if (userIds.length === 0) return ERR('Tidak ada user target', 400);

  const notifications = userIds.map(uid => ({ user_id: uid, anime_id: animeId || null, message: message.trim(), is_read: false }));
  const { error } = await supabase.from('notifications').insert(notifications);
  if (error) throw error;

  await supabase.from('admin_logs').insert({ admin_id: admin.id, action: targetUsers ? 'Sent notification' : 'Broadcast notification', target_type: 'notification', details: { message, targetCount: userIds.length, animeId } });
  return json({ message: `Notifikasi terkirim ke ${userIds.length} user`, count: userIds.length });
}

async function handleAdminLogs(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  const sp = new URL(request.url).searchParams;
  const page = parseInt(sp.get('page') || '1');
  const limit = parseInt(sp.get('limit') || '30');

  const { data, count, error } = await supabase.from('admin_logs')
    .select('*, users!admin_logs_admin_id_fkey(username)', { count: 'exact' })
    .order('created_at', { ascending: false }).range((page - 1) * limit, page * limit - 1);
  if (error) throw error;

  const logs = data?.map((l: any) => ({ ...l, admin_username: l.users?.username || 'System', users: undefined })) || [];
  return json({ logs, total: count || 0, page, totalPages: Math.ceil((count || 0) / limit) });
}

async function handleDownloadSource(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin) return ERR('Forbidden', 403);
  
  // Disable this on Vercel production to keep build size small & avoid NFT errors
  if (process.env.NODE_ENV === 'production' && process.env.VERCEL) {
    return ERR('Fitur download source dinonaktifkan di Vercel Production. Gunakan di localhost.', 403);
  }

  // Anti-NFT trace hack: hide the path from Next.js analyzer
  const getRoot = () => process.cwd();
  const rootDir = getRoot();
  
  const sp = new URL(request.url).searchParams;
  const includeEnv = sp.get('env') === 'true';
  const zip = new JSZip();
  
  // Folders to include
  const targets = ['src', 'public', 'supabase'];
  const rootFiles = ['package.json', 'tsconfig.json', 'next.config.ts', 'tailwind.config.ts', 'postcss.config.mjs'];
  if (includeEnv) rootFiles.push('.env.local', '.env', '.env.example');
  else rootFiles.push('.env.example');

  const addFolder = (dir: string, zipPath: string) => {
    const fullPath = path.join(/*turbopackIgnore: true*/ rootDir, dir);
    if (!fs.existsSync(fullPath)) return;
    
    const items = fs.readdirSync(fullPath);
    for (const item of items) {
      const itemPath = path.join(/*turbopackIgnore: true*/ fullPath, item);
      const stat = fs.statSync(itemPath);
      
      if (stat.isDirectory()) {
        if (item === 'node_modules' || item === '.next' || item === '.git') continue;
        addFolder(path.join(dir, item), path.join(zipPath, item));
      } else {
        const content = fs.readFileSync(itemPath);
        zip.file(path.join(zipPath, item), content);
      }
    }
  };

  // Add root files
  for (const file of rootFiles) {
    const filePath = path.join(/*turbopackIgnore: true*/ rootDir, file);
    if (fs.existsSync(filePath)) {
      zip.file(file, fs.readFileSync(filePath));
    }
  }

  // Add key folders
  for (const folder of targets) {
    addFolder(folder, folder);
  }

  const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
  
  return new NextResponse(zipBuffer as any, {
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="aniverse-source${includeEnv ? '-with-env' : ''}.zip"`,
    },
  });
}
