'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/components/AuthProvider';
import Navbar from '@/components/Navbar';
import BottomNav from '@/components/BottomNav';
import { getRank, getXpProgress, XP_PER_LEVEL, RANKS } from '@/lib/constants';
import { useRouter } from 'next/navigation';

export default function ProfilePage() {
  const { user, logout, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-bg-primary">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 pt-10">
          <div className="flex flex-col items-center mb-6">
            <div className="w-[84px] h-[84px] rounded-full skeleton mb-4" />
            <div className="h-6 w-32 skeleton mb-2" />
            <div className="h-4 w-20 skeleton" />
          </div>
        </div>
        <BottomNav />
      </div>
    );
  }

  const rank = getRank(user.level);
  const xpPct = getXpProgress(user.xp);
  const initial = (user.username || 'AV').slice(0, 2).toUpperCase();

  const handleLogout = async () => {
    if (!confirm('Yakin ingin keluar dari AniVerse?')) return;
    await logout();
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-bg-primary pb-24">
      <Navbar />
      <main className="max-w-2xl mx-auto px-4 pt-5">
        {/* Profile Header */}
        <div className="flex flex-col items-center mb-6">
          <div
            className="w-[84px] h-[84px] rounded-full flex items-center justify-center text-[28px] font-extrabold text-white mb-3.5"
            style={{ background: `linear-gradient(135deg, ${rank.color}, #0284C7)`, boxShadow: `0 8px 28px ${rank.color}4D` }}
          >
            {initial}
          </div>
          <h2 className="text-[21px] font-extrabold">{user.username}</h2>
          <p className="text-[11px] text-text-muted tracking-[1.5px] mt-1">{user.id.slice(0, 8).toUpperCase()}</p>
          
          <div
            className="inline-flex items-center gap-1.5 mt-2.5 px-3.5 py-1.5 rounded-full text-[12.5px] font-bold"
            style={{ background: `${rank.color}20`, color: rank.color }}
          >
            <span className="text-base">{rank.emoji}</span>
            {rank.name}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-4">
          <div className="bg-bg-secondary rounded-2xl p-3.5 text-center">
            <div className="text-[21px] font-extrabold" style={{ color: rank.color }}>{user.level}</div>
            <div className="text-[10px] text-text-muted mt-1">Level</div>
          </div>
          <div className="bg-bg-secondary rounded-2xl p-3.5 text-center">
            <div className="text-[21px] font-extrabold text-sky-d">{user.xp}</div>
            <div className="text-[10px] text-text-muted mt-1">Total XP</div>
          </div>
          <div className="bg-bg-secondary rounded-2xl p-3.5 text-center">
            <div className="text-[21px] font-extrabold text-mint">{user.title}</div>
            <div className="text-[10px] text-text-muted mt-1">Title</div>
          </div>
        </div>

        {/* XP Progress Card */}
        <div className="bg-bg-secondary rounded-2xl p-4 mb-4">
          <div className="flex justify-between items-center mb-2.5">
            <span className="text-sm font-bold">Progress XP</span>
            <span className="text-xs text-text-muted">{user.xp % XP_PER_LEVEL} / {XP_PER_LEVEL} XP</span>
          </div>
          <div className="h-2 bg-border-light rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${xpPct}%`, background: `linear-gradient(90deg, ${rank.color}, #0EA5E9)` }}
            />
          </div>
          <div className="text-[11px] text-text-muted mt-1.5">
            Level {user.level} → Level {user.level + 1}
          </div>
        </div>

        {/* Rank Progress */}
        <div className="bg-bg-secondary rounded-2xl p-4 mb-4">
          <h3 className="text-sm font-bold mb-3">Rank Progress</h3>
          <div className="space-y-2.5">
            {RANKS.map((r, i) => {
              const unlocked = user.level >= r.minLv;
              const next = RANKS[i + 1];
              const isCurrent = unlocked && (!next || user.level < next.minLv);
              return (
                <div key={r.name} className="flex items-center gap-3">
                  <span className="text-lg w-7 text-center">{r.emoji}</span>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="text-xs font-bold" style={{ color: unlocked ? r.color : 'var(--color-text-muted)' }}>
                        {r.name} {isCurrent && '←'}
                      </span>
                      <span className="text-[10px] text-text-muted">Lv.{r.minLv}</span>
                    </div>
                    <div className="h-1 bg-border-light rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: unlocked ? '100%' : `${Math.min((user.level / r.minLv) * 100, 100)}%`,
                          background: unlocked ? r.color : 'var(--color-border-light)',
                        }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Account info */}
        <div className="bg-bg-secondary rounded-2xl p-4 mb-4">
          <h3 className="text-sm font-bold mb-3">Informasi Akun</h3>
          <div className="space-y-2.5">
            <div className="flex justify-between text-sm">
              <span className="text-text-muted">Username</span>
              <span className="font-bold">{user.username}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-text-muted">Bergabung</span>
              <span className="font-bold">{new Date(user.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-text-muted">Rank</span>
              <span className="font-bold" style={{ color: rank.color }}>{rank.name}</span>
            </div>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full py-3.5 bg-bg-secondary border border-red/20 rounded-2xl text-red text-sm font-bold hover:bg-red/5 transition-colors btn-press"
        >
          Keluar dari Akun
        </button>
      </main>
      <BottomNav />
    </div>
  );
}
